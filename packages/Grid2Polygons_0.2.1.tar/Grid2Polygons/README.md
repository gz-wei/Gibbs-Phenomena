# Grid2Polygons

[![CRAN_Status_Badge](https://www.r-pkg.org/badges/version/Grid2Polygons)](https://CRAN.R-project.org/package=Grid2Polygons)
[![](https://cranlogs.r-pkg.org/badges/Grid2Polygons?color=brightgreen)](https://CRAN.R-project.org/package=Grid2Polygons)
[![License](http://img.shields.io/badge/license-GPL%20%28%3E=%202%29-brightgreen.svg?style=flat)](http://www.gnu.org/licenses/gpl-2.0.html)

The `Grid2Polygons` function has been deprecated; please use `inlmisc::Grid2Polygons` instead,
see **[inlmisc](https://CRAN.R-project.org/package=inlmisc)** package.

## License

GPL-2 or GPL-3.
These are "copy-left" licenses.
This means that anyone who distributes the code in a bundle must license the whole bundle in a GPL-compatible way.
Additionally, anyone who distributes modified versions of the code (derivative works) must also make the source code available.
GPL-3 is a little stricter than GPL-2, closing some older loopholes.

# IBM Confidential
# OCO Source Materials
# 5747-SM3
# © Copyright IBM Corp. 1992, 1993
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#
#' R wrapper to AreaTracker
#' 
#' This is an R wrapper for calling the Java area tracking codes
#'
#' @param path.java Fully qualified path the java executable.
#' @param jvm.args The memory specification. This default is for WinXP 32-bit
#' @param json.file The json output from \code{\link{rbclientR}}.
#' @param out.file The output filename. There will be two files produced: One
#' will be named out.file, and the second will be named out.file + '.stats'
#' @param algo.params A json file containing the parameters for the SCIT storm
#' or the convolution method detection algorithms.
#' 
#' @details This applies the area-tracking algorithm to the sequence of scans in
#' the json file.
#'
#' @export
#' @author Sayan Ranu, Prithu Banerjee, 
#' Vik Gopal
#'
#' @return Returns none. If it completes without error, a text file with 
#' ".csv" extension should be produced.

areaTrackingR <- function(path.java="\"C:\\Program Files\\IBM\\Java60\\jre\\bin\\java.exe\"",
  jvm.args="-Xmx512m", json.file, out.file="test.csv", algo.params) {

  jars <- c("StormDetection.jar", "commons-cli-1.2.jar",
    "commons-math3-3.0.jar", "jackson-all-1.9.11.jar")
  path.to.jars <- path.package("selextR")

  if(missing(algo.params))
    stop("A json file with the area-tracking parameters must be specified.\n")
  if(!file.exists(algo.params))
    stop("Specified parameter file does not exist\n")

  if(Sys.info()['sysname'] ==  "Windows") {
    path.to.jars <- strsplit(path.to.jars, "/")[[1]]
    path.to.jars <- paste(path.to.jars, collapse="\\")
    path.to.jars <- paste(path.to.jars, "jar", jars, sep="\\")
    path.to.jars <- paste('"', path.to.jars, '"', sep="")
    path.to.jars <- paste(path.to.jars, collapse=";")
  } else {
    path.to.jars <- paste(path.to.jars, "jar", jars, sep="/")
    path.to.jars <- paste(path.to.jars, collapse=":")
  }

  cat("\nRunning Prithu's code... \n")
  cmd2 <- paste(path.java, jvm.args, '-classpath', path.to.jars, 
	    'com.ibm.cdom.ext.util.radar.AreaTracking', 
	    '-params', algo.params,
	    '-json', json.file, '-f', out.file, sep=" ")
  system(cmd2)
  cat("Done with Prithu's code.\n")
}

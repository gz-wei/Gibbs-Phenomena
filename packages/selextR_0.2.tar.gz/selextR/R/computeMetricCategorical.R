# IBM Confidential
# OCO Source Materials
# 5747-SM3
# © Copyright IBM Corp. 1992, 1993
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#
#' Compute forecast skill
#' 
#' Compute the traditional skill of a forecast for a given pair of observed and 
#' predicted storms.
#'
#' @param predicted.storm An object of class stormPredicted.
#' @param observed.storm An object of class storm.
#' @param height The height of the storms to compare.
#' @param ref.thresh The reflectivity threshold to consider as an `active' cell.
#' @param ... Unused for now.
#'
#' @details This function computes three of the customary error metrics in
#' forecasting: Probability of Detection (POD), False Alarm Rate (FAR) and Critical
#' Success Index (CSI). 
#'
#' @export
#' @author Vik Gopal
#'
#' @seealso \code{\link{computeMetrics}}
#'
#' @return Returns a numeric named vector containing all the traditional error 
#' metrics.

computeMetricCategorical <- function(predicted.storm, observed.storm, height=1, 
  ref.thresh=35, ...) {

  pred.hts <- laply(predicted.storm$data, function(z) z$height)
  if(!height %in% pred.hts)
    stop(paste("No predicted storms found at height of", height, "km.", sep=" "))
  id <- match(height, pred.hts)
  predicted.grid <- predicted.storm$data[[id]]$reflectivity

  obs.hts <- laply(observed.storm$data, function(x) x$height)
  if(!height %in% obs.hts)
    stop(paste("No storm observed at height of", height, "km.", sep=" "))
  id <- match(height, obs.hts)
  observed.pts <- observed.storm$data[[id]]$sp.pts
 
  observed.grid <- aggregate(observed.pts, geometry(predicted.grid), meanDb)
  observed.values <- observed.grid$dBZ
  remove.these <- which(is.na(observed.values))

  observed.values <- observed.values[-remove.these]
  predicted.values <- predicted.grid$dBZ[-remove.these]

  YY <- sum(observed.values > ref.thresh & predicted.values > ref.thresh)
  NN <- sum(observed.values <= ref.thresh & predicted.values <= ref.thresh)
  YN <- sum(observed.values <= ref.thresh & predicted.values > ref.thresh)
  NY <- sum(observed.values > ref.thresh & predicted.values <= ref.thresh)

  pod <- YY/(YY+NY)
  far <- YN/(YY+YN)
  csi <- YY/(YY+NY+YN)
  
  out <- c(pod, far, csi)
  names(out) <- c("pod", "far", "csi")
  out
}

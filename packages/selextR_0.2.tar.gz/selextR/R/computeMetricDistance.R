# IBM Confidential
# OCO Source Materials
# 5747-SM3
# © Copyright IBM Corp. 1992, 1993
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#
#' Compute error in location
#' 
#' Compute the euclidean norm between centroids.
#'
#' @param predicted.storm An object of class stormPredicted.
#' @param observed.storm An object of class storm.
#' @param height The height of the storms to compare.
#' @param ... Unused for now.
#'
#' @details This function computes the distance between the centroid of the
#' predicted storm and the observed one, in km.
#'
#' @export
#' @author Vik Gopal
#'
#' @seealso \code{\link{computeMetrics}}
#'
#' @return Returns a scalar containing the computed error metric.

computeMetricDistance <- function(predicted.storm, observed.storm, height=1, ...) {
  pred.hts <- laply(predicted.storm$data, function(z) z$height)
  if(!height %in% pred.hts)
    stop(paste("No predicted storms found at height of", height, "km.", sep=" "))
  id <- match(height, pred.hts)
  predicted.storm.centroid <- predicted.storm$data[[id]]$centre

  obs.hts <- laply(observed.storm$data, function(x) x$height)
  if(!height %in% obs.hts)
    stop(paste("No storm observed at height of", height, "km.", sep=" "))
  id <- match(height, obs.hts)
  observed.storm.centroid <-
    drop(as.matrix(observed.storm$data[[id]]$stats[,c(1,2)]))

  norm(observed.storm.centroid - predicted.storm.centroid, "2")
}

# IBM Confidential
# OCO Source Materials
# 5747-SM3
# © Copyright IBM Corp. 1992, 1993
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#
#' Compute error in reflectivity field.
#' 
#' Compute the euclidean distance between the observed quantiles and predicted
#' quantiles.
#'
#' @param predicted.storm An object of class stormPredicted.
#' @param observed.storm An object of class storm.
#' @param height The height of the storms to compare.
#' @param qtles The vector of quantiles to compare.
#' @param ... Unused for now.
#'
#' @details This function computes the euclidean norm between two vectors of
#' quantiles: in the predicted storm and in the observed storm. Quantiles should
#' be specified as percentages, for e.g. the median should be specified as 50, not
#' 0.5. 
#'
#' @export
#' @author Vik Gopal
#'
#' @seealso \code{\link{computeMetrics}}
#'
#' @return Returns a scalar containing the computed error metric.

computeMetricRefQtles <- function(predicted.storm, observed.storm, height=1,
  qtles=50, ...) {
  
  obs.qtles <- drop(as.matrix(getFeatureRefQtles(observed.storm, qtles=qtles,
    qtles.ht=height)))

  pred.hts <- laply(predicted.storm$data, function(z) z$height)
  if(!height %in% pred.hts)
    stop(paste("No predicted storms found at height of", height, "km.", sep=" "))
  id <- match(height, pred.hts)
  pred.ref <-  predicted.storm$data[[id]]$reflectivity$dBZ
  pred.qtles <- quantile(pred.ref, qtles/100)
  
  if(length(obs.qtles) == 1) {
    out <- abs(obs.qtles - pred.qtles)
    names(out) <- NULL
    return(out)
  } else {
    return(norm(pred.qtles - obs.qtles, "2"))
  }
}

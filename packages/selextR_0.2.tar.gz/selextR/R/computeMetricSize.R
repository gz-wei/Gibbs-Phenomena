# IBM Confidential
# OCO Source Materials
# 5747-SM3
# © Copyright IBM Corp. 1992, 1993
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#
#' Compute error in size
#' 
#' Compute the difference in size between predicted and observed storms.
#'
#' @param predicted.storm An object of class stormPredicted.
#' @param observed.storm An object of class storm.
#' @param height The height of the storms to compare.
#' @param convex.hull A logical argument indicating if the convex hull of the
#' storm should be used.
#' @param ... Unused for now.
#'
#' @details This function computes the following absolute difference:
#' area of predicted storm - area of observed storm at height height.
#'
#' @export
#' @author Vik Gopal
#'
#' @seealso \code{\link{computeMetrics}}
#'
#' @return Returns a scalar containing the computed error metric.

computeMetricSize <- function(predicted.storm, observed.storm, height=1, 
  convex.hull=FALSE, ...) {
  pred.hts <- laply(predicted.storm$data, function(z) z$height)
  if(!height %in% pred.hts)
    stop(paste("No predicted storms found at height of", height, "km.", sep=" "))
  id <- match(height, pred.hts)
  predicted.storm.area <- predicted.storm$data[[id]]$ellipse@polygons[[1]]@area/1e+06

  obs.hts <- laply(observed.storm$data, function(x) x$height)
  if(!height %in% obs.hts)
    stop(paste("No storm observed at height of", height, "km.", sep=" "))
  id <- match(height, obs.hts)
  observed.storm.poly <- extractStormOutline(observed.storm, height=height,
    convex.hull=convex.hull)
  observed.storm.area <- observed.storm.poly@polygons[[1]]@area/1e+06

  abs(observed.storm.area - predicted.storm.area)
}

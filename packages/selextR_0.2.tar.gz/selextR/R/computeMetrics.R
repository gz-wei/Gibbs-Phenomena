# IBM Confidential
# OCO Source Materials
# 5747-SM3
# © Copyright IBM Corp. 1992, 1993
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#
#' Compute metrics
#' 
#' Compute all error metrics for a given pair of observed and predicted storms.
#'
#' @param predicted.storm An object of class stormPredicted.
#' @param observed.storm An object of class storm.
#' @param ... Can contain named arguments that will be passed to the individual
#' functions for computing metrics. See Details for more details.
#'
#' @details This function applies the following functions to the pair of storms
#' and returns a named vector: computeMetricDistance, computeMetricSize,
#' computeMetricAreaOverlap, computeMetricRefQtles and computeMetricCategorical.
#' The additional arguments that can be passed to those functions are:
#' height, convex.hull, qtles and ref.thresh. Please see the individual
#' functions on what the functions compute.
#'
#' @export
#' @author Vik Gopal
#'
#' @seealso \code{\link{rbclientR}}
#'
#' @return Returns a numeric named vector containing all the error metrics.

computeMetrics <- function(predicted.storm, observed.storm, ...) {
  args.list <- list(...)
  if("height" %in% names(args.list))
    height <- args.list[["height"]] else
    height <- 1
  if("convex.hull" %in% names(args.list))
    convex.hull <- args.list[["convex.hull"]] else
    convex.hull <- FALSE
  if("qtles" %in% names(args.list))
    qtles <- args.list[["qtles"]] else
    qtles <- 50
  if("ref.thresh" %in% names(args.list))
    ref.thresh <- args.list[["ref.thresh"]] else
    ref.thresh <- 40
 
  dist <- computeMetricDistance(predicted.storm, observed.storm, 
    height=height)
  size <- computeMetricSize(predicted.storm, observed.storm, 
    height=height, convex.hull=FALSE)
  overlap <- computeMetricAreaOverlap(predicted.storm, observed.storm, 
    height=height, convex.hull=FALSE)
  ref.qtles <- computeMetricRefQtles(predicted.storm, observed.storm, 
    height=height, qtles=qtles)
  categorical <- computeMetricCategorical(predicted.storm, observed.storm, 
    height=height, ref.thresh=ref.thresh)

  out <- c(dist, size, overlap, ref.qtles, categorical)
  names(out)[1:4] <- c("dist", "size", "overlap", "qtles")
  out
}

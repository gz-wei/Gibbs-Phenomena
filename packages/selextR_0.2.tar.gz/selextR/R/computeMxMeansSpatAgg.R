# IBM Confidential
# OCO Source Materials
# 5747-SM3
# © Copyright IBM Corp. 1992, 1993
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#
#' Compute means within new cells.
#' 
#' Spatial aggregation of the radar requires averaging over cells. This function
#' computes that mean and returns a matrix with those new cell means.
#'
#' @param mat1 Numeric matrix with the original radar readings.
#' @param average.over This is an integer vector of length 2. It specifies how
#' many grids in the x- and y- direction should be combined. For example, c(2,2)
#' says each cell in the new grid should contain 4 of the original grid squares.
#' @param meas.scale A character string, either "org" or "db", corresponding to
#' either original or decibel scale.
#'
#' @export
#' @author Vik Gopal
#'
#' @return Returns a matrix with the means within those cells.

computeMxMeansSpatAgg <- function(mat1, average.over=c(2,2),
  meas.scale=c("org","db")) {

  if(ncol(mat1) %% average.over[1] != 0)
    stop("x1 dimension cannot be grouped as specified.\n")
  if(nrow(mat1) %% average.over[2] != 0)
    stop("x2 dimension cannot be grouped as specified.\n")

  total.new.squares <- nrow(mat1)*ncol(mat1) / prod(average.over)
  root.new.mx <- matrix(1:total.new.squares, nrow=nrow(mat1)/average.over[2], 
    ncol=ncol(mat1)/average.over[1], byrow=TRUE)
  
  root.new.mx <- t(apply(root.new.mx, 1, function(x) rep(x,
    each=average.over[1])))
  id.mx <- apply(root.new.mx, 2, function(x) rep(x,
    each=average.over[2]))

  if(meas.scale == "org") {
    mean.vector <- tapply(as.vector(mat1), as.vector(id.mx), mean, 
      na.rm=TRUE) 
  } else if (meas.scale == "db")
    mean.vector <- tapply(as.vector(mat1), as.vector(id.mx), meanDb)
  
  mean.Mat <- matrix(mean.vector, nrow=nrow(mat1)/average.over[2],
    ncol=ncol(mat1)/average.over[1], byrow=TRUE)
  mean.Mat
}

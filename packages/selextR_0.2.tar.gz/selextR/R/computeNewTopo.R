# IBM Confidential
# OCO Source Materials
# 5747-SM3
# © Copyright IBM Corp. 1992, 1993
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#
#' Compute new grid topology
#' 
#' Spatial aggregation of the radar requires a new grid topology. This function
#' computes and returns that new grid topology according to how the radar cells are
#' to be spatially aggregated.
#'
#' @param old.topo This is the old topology, i.e. the original spatial grid to
#' be converted from.
#' @param average.over This is an integer vector of length 2. It specifies how
#' many grids in the x- and y- direction should be combined. For example, c(2,2)
#' says each cell in the new grid should contain 4 of the original grid squares.
#'
#' @export
#' @author Vik Gopal
#'
#' @return Returns an object of class GridTopology, with the new specification
#' for the grid.

computeNewTopo <- function(old.topo, average.over=c(2,2)) {
  topo1 <- as.data.frame(old.topo)

  if(topo1$cells.dim[1] %% average.over[1] != 0)
    stop("x1 dimension cannot be grouped as specified.\n")
  if(topo1$cells.dim[2] %% average.over[2] != 0)
    stop("x2 dimension cannot be grouped as specified.\n")

  new.cell.dims <- as.integer(topo1$cells.dim / average.over)
  new.cellsize <- topo1$cellsize * average.over

  x1.off <- mean(seq(topo1$cellcentre.offset[1], by=topo1$cellsize[1],
    length=average.over[1]))
  x2.off <- mean(seq(topo1$cellcentre.offset[2], by=topo1$cellsize[2],
    length=average.over[2]))
  new.cellcentre.offset <- c(x1.off, x2.off)

  GridTopology(new.cellcentre.offset, new.cellsize, new.cell.dims)
}

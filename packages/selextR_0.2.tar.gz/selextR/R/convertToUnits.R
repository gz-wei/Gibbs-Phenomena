# IBM Confidential
# OCO Source Materials
# 5747-SM3
# © Copyright IBM Corp. 1992, 1993
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#
#' Convert to physical units
#' 
#' Converts the 8-bit readings from the radar into the physical units.
#'
#' @param data This contains the data, as output by rbclient (typically between
#' 0 and 255. Usually a matrix or a numeric data frame.
#'
#' @param prod.type This is a character vector of length 1, and it specifies 
#' what the product type is. It has to be one of those specified in the formal
#' argument for now.
#'
#' @export
#' @author Vik Gopal
#'
#' @examples 
#' data <- c(0, 3, 255)
#' convertToUnits(data, "dBZ")
#'
#' @return Returns an object of the same type as earlier, but with the true 
#' units.

convertToUnits <- function(data, prod.type=c("dBZ", "V", "W")) {
  if(prod.type == "dBZ") 
    return(0.5*data - 32) else 
  if(prod.type == "W") 
    return((15/254)*(data - 1)) else
  if(prod.type == "V") 
    return((60/254)*(data-1) - 30)
}

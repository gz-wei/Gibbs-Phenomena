# IBM Confidential
# OCO Source Materials
# 5747-SM3
# © Copyright IBM Corp. 1992, 1993
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#
#' Create an ellipse
#' 
#' Create an ellipse as a SpatialPolygons object.
#'
#' @param major.axis A vector of length 2
#' @param minor.axis A vector of length 2
#' @param centre.xy A vector of length 2 indicating the location.
#'
#' @details This function will create an ellipse as a SpatialPolygons object.
#'
#' @export
#' @author Vik Gopal
#'
#' @return Returns a SpatialPolygons object.

#######################################################
# Function to create points corresponding to an ellipse
#######################################################
# major.axis and minor.axis should both be vectors of length 2
#
createEllipse <- function(major.axis, minor.axis, centre.xy) {
  a <- norm(major.axis, "2")
  b <- norm(minor.axis, "2")

  rot.theta <- atan2(major.axis[2], major.axis[1])
  rot.matrix <- matrix(c(cos(rot.theta), sin(rot.theta), 
    -sin(rot.theta), cos(rot.theta)), nrow=2, ncol=2)

  x.vals <- seq(from=a, to=-a, length.out=100)
  y.vals <- b * sqrt( 1 - (x.vals/a)^2)
  x.vals <- c(x.vals, rev(x.vals)[-1]) 
  y.vals <- c(y.vals, -y.vals[-1]) 

  coords <- cbind(x.vals, y.vals)
  coords <- t(rot.matrix %*% t(coords))
  coords[,1] <- coords[,1] + centre.xy[1]
  coords[,2] <- coords[,2] + centre.xy[2]

  coords
}

# IBM Confidential
# OCO Source Materials
# 5747-SM3
# © Copyright IBM Corp. 1992, 1993
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#
#' Create a predicted storm
#' 
#' Create a predicted storm object.
#'
#' @param ... A collection of objects that were output from 
#' createPredictedStormHt.
#' @param timestamp A POSIXct object specifying the time of the prediction.
#'
#' @export
#' @author Vik Gopal
#'
#' @seealso
#' \code{\link{createPredictedStormHt}}
#' 
#' @return Returns an object of class `stormPredicted'.

createPredictedStorm <- function(..., timestamp) {
  if(missing(timestamp)) {
    stop("
    `timestamp' has to be a named argument, 
    and has to specified as a POSIXct object\n")
  }

  data <- list(...)

  out <- list(timestamp=timestamp, data=data)
  class(out) <- "stormPredicted"
  out
}

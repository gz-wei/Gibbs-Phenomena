# IBM Confidential
# OCO Source Materials
# 5747-SM3
# © Copyright IBM Corp. 1992, 1993
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#
#' Create a predicted storm
#' 
#' Create a predicted storm object at a particular height.
#'
#' @param major.axis A vector of length 2.
#' @param minor.axis A vector of length 2.
#' @param centre.xy A vector of length 2 that denotes the centre of the ellipse.
#' @param ref.grid An object of class SpatialGridDataFrame, containing the
#' reflectivity values within the storm. There must be a column named `dBZ' in the
#' object.
#' @param height The height that this ellipse and grid correspond to.
#'
#' @export
#' @author Vik Gopal
#'
#' @seealso
#' \code{\link{createPredictedStorm}}
#' 
#' @return Returns a list.
#
createPredictedStormHt <- function(major.axis, minor.axis, centre.xy,
                                   ref.grid, height) {
  if(class(ref.grid) != "SpatialGridDataFrame")
    stop("ref.grid has to be of class SpatialGridDataFrame\n")

  ell <- createEllipse(major.axis, minor.axis, centre.xy)
  ell <- SpatialPolygons(list(Polygons(list(Polygon(ell,hole=FALSE)),'1')), 
    proj4string=CRS(proj4string(ref.grid)))

  list(height=height, ellipse=ell, reflectivity=ref.grid, major.axis=major.axis,
    minor.axis=minor.axis, centre=centre.xy)
}

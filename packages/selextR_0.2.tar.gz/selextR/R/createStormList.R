# IBM Confidential
# OCO Source Materials
# 5747-SM3
# © Copyright IBM Corp. 1992, 1993
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#
#' Create a list of storm objects
#' 
#' Creates a list of storm objects that can be plotted or analysed.
#'
#' @param storm.obj The data-frame that is output from
#' \code{\link{readStormObjects}}.
#' @param selex.scan.list The object of class SelexScanList from
#' \code{\link{createSelexScanList}}.
#' @param storm.stats The data-frame that is output from
#' \code{\link{readStormStats}}.
#'
#' @export
#' @author Vik Gopal
#'
#' @details This function returns a list of objects of class storm. Each object
#' of class storm is a list with the following components: (1) an md5 digest of the
#' raw coordinates from Sayan's code, (2) timestamp of the storm (3) The data of
#' the storm, as SpatialPointsDataFrame with the dBZ in the data slot.
#'
#' @examples 
#' \dontrun{start.time <- "2011-05-20 07:09:00"}
#' \dontrun{end.time <- "2011-05-20 07:11:00"}
#' \dontrun{rbclientR(start.time, end.time, out.file='demo.json')}
#' \dontrun{scans <- createSelexScanList('demo.json')}
#' \dontrun{stormDetectionR(json.file='demo.json', ref.thresh=35, size.thresh=1000, out.file='demo.csv')}
#' \dontrun{storm.stats <- readStormStats('demo.csv.stats')}
#' \dontrun{storm.objs <- readStormObjects('demo.csv')}
#' \dontrun{storm.list<- createStormList(storm.objs, scans, storm.stats)}
#' \dontrun{class(storm.list)}
#' \dontrun{summary(storm.list)}
#'
#' @return Returns an object of class stormList. This is a list of objects of
#' class "storm". 

createStormList <- function(storm.obj, selex.scan.list, storm.stats) {
  out.list <- dlply(storm.obj, "storm.id", rawStormToSpatialPoints, selex.scan.list, 
    storm.stats) 
  names(out.list) <- 1:length(out.list)

  class(out.list) <- "stormList"
  out.list
}

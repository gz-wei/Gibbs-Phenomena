# IBM Confidential
# OCO Source Materials
# 5747-SM3
# © Copyright IBM Corp. 1992, 1993
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#
#' Estimate an ellipse from a cloud
#' 
#' Estimate an ellipse that contains a certain percentage of a cloud of points.
#'
#' @param sp.pts An object of class SpatialPoints.
#' @param confidence The percentage of points that the resulting ellipse should
#' contain.
#'
#' @details This function will fit a bivariate normal distribution to a cloud of
#' points using method of moments. Then it will brute force contour lines of
#' that distribution until the desired proportion of points fall within the
#' ellipse.
#'
#' @export
#' @author Vik Gopal
#'
#' @return Returns a list with 3 components - the major axis vector, the minor
#' axis vector and the centre of the ellipse.

estimateEllipse <- function(sp.pts, confidence=0.95) {
  coords <- coordinates(sp.pts)
  found <- FALSE
  total.num.pts <- length(sp.pts)

  c1 <- 1
  eigen.covar <- eigen(cov(coords))
  major.axis <- eigen.covar$vector[,1]
  minor.axis <- eigen.covar$vector[,2]
  sqrt.e.value.1 <- sqrt(eigen.covar$values[1])
  sqrt.e.value.2 <- sqrt(eigen.covar$values[2])
  means.xy <- colMeans(coords)

  while(!found) {
    ell <- createEllipse(c1*sqrt.e.value.1*major.axis,
      c1*sqrt.e.value.2*minor.axis, means.xy)
    ell <- SpatialPolygons(list(Polygons(list(Polygon(ell,hole=FALSE)),'1')), 
      proj4string=CRS(proj4string(sp.pts)))
    
    prop.contained <- sum(!is.na(over(sp.pts, ell)))/total.num.pts
    if(prop.contained > confidence) {
      found <- TRUE
      major.axis <- c1*sqrt.e.value.1*major.axis
      minor.axis <- c1*sqrt.e.value.2*minor.axis
    } else {
      c1 <- c1 + 0.2
    }
  }

  list(major.axis=major.axis, minor.axis=minor.axis, means.xy=means.xy)
}

# IBM Confidential
# OCO Source Materials
# 5747-SM3
# © Copyright IBM Corp. 1992, 1993
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#
#' Extract overlap area
#' 
#' Extract area of overlap with Singapore mainland
#'
#' @param obj An object of class storm
#' @param ... If it contains a logical flag, stations=TRUE, then a logical 
#' matrix reflecting which stations were affected by this storm will also be 
#' returned.
#'
#' @details This extracts the area of overlap with the convex hull around the 
#' mainland of Singapore, as given by sgBd[50,].
#'
#' @export
#' @author Vik Gopal
#'
#' @return The area overalapped by the projected storm with the mainland of
#' Singapore in square kilometres.

getFeatureAreaOverlap <- function(obj, ...) {
  args.list <- list(...)
  if("stations" %in% names(args.list))
    stations <- args.list$stations else
    stations <- FALSE

  projected.poly <- projectStorm(obj)
  if(!identical(proj4string(projected.poly), proj4string(sgBd))){
    sgBd <- spTransform(sgBd, CRS(proj4string(projected.poly)))
    stns <- spTransform(stns, CRS(proj4string(projected.poly)))
  }
  area <- gIntersection(projected.poly, gConvexHull(sgBd[50,]))
  if(is.null(area))
    overlap.area <- 0 else
    overlap.area <- gArea(area)/1e+06
 
  overlap.area <- matrix(overlap.area, nrow=1, ncol=1)
  overlap.area <- as.data.frame(overlap.area)
  colnames(overlap.area) <- "AreaOverlap.proj"

  if(stations==TRUE) {
    overlap.stn <- !is.na(over(stns, projected.poly))
    overlap.stn <- matrix(overlap.stn, nrow=1)
    overlap.stn <- as.data.frame(overlap.stn)
    colnames(overlap.stn) <- paste("S", stns$Stn, sep=".")
    overlap.area <- cbind(overlap.area, overlap.stn)
  }
  overlap.area
}

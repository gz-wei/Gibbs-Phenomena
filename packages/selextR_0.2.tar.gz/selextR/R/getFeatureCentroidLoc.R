# IBM Confidential
# OCO Source Materials
# 5747-SM3
# © Copyright IBM Corp. 1992, 1993
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#
#' Extract centroid locations
#' 
#' Extract location of centroid at each timestamp.
#'
#' @param obj An object of class storm
#' @param ... Unused for now.
#'
#' @details This extracts the centroid of the storm object.
#'
#' @export
#' @author Vik Gopal
#'
#' @return A data.frame with 2 columns specifying the coordinates of the
#' centroid.

getFeatureCentroidLoc <- function(obj, ...) {
  loc <- obj$stats[ ,c("Centroid.x", "Centroid.y")]
  loc
}

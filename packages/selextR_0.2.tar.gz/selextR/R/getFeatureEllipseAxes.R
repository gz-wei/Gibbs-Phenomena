# IBM Confidential
# OCO Source Materials
# 5747-SM3
# © Copyright IBM Corp. 1992, 1993
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#
#' Extract ellipse representation
#' 
#' Extract the ellipse representation of a storm object
#'
#' @param obj An object of class storm
#' @param ... This list of arguments CAN contain an argument named confidence,
#' which will be passed on to estimateEllipse function.
#'
#' @details This returns the details of the ellipse representation of a storm at
#' individual heights. The ellipse for each height is defined by the length of the
#' major axis, minor axis, and the angle (in radian) that the major axis makes with
#' the positive x-axis.
#'
#' @export
#' @author Vik Gopal
#'
#' @return A vector containing the ellipse representation at each height of the
#' storm. Each height is made up of three variables.
getFeatureEllipseAxes <- function(storm.obj, ...) {
  ht.vector <- unlist(lapply(storm.obj$data, function(x) x$height))

  args.list <- list(...)
  if("confidence" %in% names(args.list))
    confidence <- args.list$confidence else
    confidence <- 0.95

  ellipse.info <- llply(storm.obj$data, function(x) estimateEllipse(x$sp.pts,
    confidence))

  ellipse.info <- ldply(ellipse.info, function(x) data.frame(maj=norm(x[[1]], 
    "2"), min=norm(x[[2]],"2"), angle=atan2(x[[1]][2],x[[1]][1])))
  ellipse.info$angle <- ifelse(ellipse.info$angle < 0, pi + ellipse.info$angle, 
    ellipse.info$angle)

  out <- matrix(1, nrow=1, ncol=nrow(ellipse.info)*3)
  out[1,] <- as.vector(as.matrix(t(ellipse.info[,-1])))
  out <- as.data.frame(out)

  colnames(out) <- paste(rep(c("maj", "min", "angle"), nrow(ellipse.info)), 
    rep(1:nrow(ellipse.info), each=3), sep=".")
  out
}

# IBM Confidential
# OCO Source Materials
# 5747-SM3
# © Copyright IBM Corp. 1992, 1993
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#
#' Extract height
#' 
#' Extract height of a storm centroid
#'
#' @param obj An object of class storm
#' @param ... Unused for now.
#'
#' @details This extracts the height of the 3-D storm in pixels.
#'
#' @export
#' @author Vik Gopal
#'
#' @return A vector of length 2 with the minimum and maximum heights of a storm.

getFeatureHeight <- function(obj, ...) {
  ht.vector <- unlist(lapply(obj$data, function(x) x$height))
 
  ht.range <- range(ht.vector)
  ht.range <- matrix(ht.range, nrow=1)
  ht.range <- as.data.frame(ht.range)
  colnames(ht.range) <- c("min.ht", "max.ht")

  ht.range
}

# IBM Confidential
# OCO Source Materials
# 5747-SM3
# © Copyright IBM Corp. 1992, 1993
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#
#' Extract maximum reflectivity
#' 
#' Extract the maximum reflectivity value at each height available.
#'
#' @param obj An object of class storm
#' @param ... Unused for now.
#'
#' @details This extracts the maximum reflectivity within the storm at each
#' individual height.
#'
#' @export
#' @author Vik Gopal
#'
#' @return The maximum reflectivity value within the storm.

getFeatureMaxRef <- function(obj, ...) {

  ht.vector <- unlist(lapply(obj$data, function(x) x$height))
 
  max.ref <- unlist(lapply(obj$data, function(x) max(x$sp.pts$dBZ, na.rm=TRUE)))

  max.ref <- matrix(max.ref, nrow=1)
  max.ref <- as.data.frame(max.ref)
  colnames(max.ref) <- paste("MaxRef", ht.vector, sep=".")
  max.ref
}

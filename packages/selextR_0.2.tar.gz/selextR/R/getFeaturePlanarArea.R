# IBM Confidential
# OCO Source Materials
# 5747-SM3
# © Copyright IBM Corp. 1992, 1993
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#
#' Extract planar area
#' 
#' Extract planar area in pixels from a single timestamp of a storm object.
#'
#' @param obj An object of class storm
#' @param ... This list of arguments MUST contain a vector argument for height.
#'
#' @details This extracts the size of the storm in pixels at the specified
#' height. The desired heights should be specified in a vector, named 'height'
#'
#' @export
#' @author Vik Gopal
#'
#' @return A vector containing the sizes at the specified heights. It will
#' contain an NA  if there is no data for that height.

getFeaturePlanarArea <- function(obj, ...) {

  args.list <- list(...)
  if(!("height" %in% names(args.list)))
    stop("'height' argument has to be provided for getFeaturePlanarArea()")

  height <- args.list$height
  ht.vector <- unlist(lapply(obj$data, function(x) x$height))
 
  id <- match(height, ht.vector)
  which.na <- which(is.na(id))

  if(length(which.na) == 0) {
    areas <- unlist(lapply(obj$data[id], function(x) length(x$sp.pts)))
  } else {
    areas <- rep(NA, length(height))
    areas[-which.na] <- unlist(lapply(obj$data[id[-which.na]], function(x) 
      length(x$sp.pts)))
  }
 
  areas <- matrix(areas, nrow=1)
  areas <- as.data.frame(areas)
  colnames(areas) <- paste("PlanarArea", height, sep=".")
  areas
}

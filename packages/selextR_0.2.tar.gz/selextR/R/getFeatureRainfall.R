# IBM Confidential
# OCO Source Materials
# 5747-SM3
# © Copyright IBM Corp. 1992, 1993
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#
#' Extract rainfall at stations
#' 
#' Extract rainfall at stations for the duration of a storm
#'
#' @param obj An object of class stormTrack
#' @param stn.list A vector containing the station ids for whom rainfall is to
#' be extracted. If this is missing, then rainfall for all stations is returned.
#' @param cdom.server This is a character vector containing the ip address of
#' the cdom server.
#'
#' @details This function extracts the rainfall from the stations specified.
#'
#' @export
#' @author Vik Gopal
#'
#' @return A data-frame containing the rainfall amounts at the specified
#' stations.

getFeatureRainfall <- function(obj, stn.list, cdom.server="10.0.0.2") {
  time.range <- range(summary(obj)$timestamp)
  # remember that the track info is in UTC!!
  time.range <- time.range + 8*60*60
  time.range <- as.character(paste(time.range, collapse=","))

  rain.data <- read.cdom(dataset="rainfall_5min", temporal=time.range,
    field="station_id,timestamp,amount", host=cdom.server)
  colnames(rain.data)[c(1,3)] <- c("Stn","S")
  rain.data$timestamp <- as.POSIXct(rain.data$timestamp)
  
  if(!missing(stn.list)) 
    rain.data <- subset(rain.data, subset = rain.data$Stn %in% stn.list)
  rain.data$Stn <- sprintf("%02d", rain.data$Stn)
  
  rain.data <- reshape(rain.data, idvar="timestamp", timevar="Stn", direction="wide",
    v.names="S")
  rain.data$timestamp <-  rain.data$timestamp - 8*60*60
  rain.data
}

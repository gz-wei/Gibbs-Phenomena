# IBM Confidential
# OCO Source Materials
# 5747-SM3
# © Copyright IBM Corp. 1992, 1993
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#
#' Extract reflectivity 
#' 
#' Extract reflectivity quantiles from a storm centroid.
#'
#' @param obj An object of class storm
#' @param ... It can contain vectors with the names qtles and qtles.ht
#' If there is no argument named qtles.ht, then the whole 3-D object is used.
#'
#' @details This extracts the size of the 3-D storm in pixels.
#'
#' @export
#' @author Vik Gopal
#'
#' @return A vector representing the requested quantiles at the specified
#' heights.

getFeatureRefQtles <- function(obj, ...) {
  args.list <- list(...)
  if(!("qtles" %in% names(args.list)))
    qtles <- c(25, 50, 75) else
    qtles <- args.list$qtles

  if(!("qtles.ht" %in% names(args.list))) {
    all.ref <- unlist(llply(obj$data, function(x) x$sp.pts$dBZ))
    out <- quantile(all.ref, probs=qtles/100)
    out <- matrix(out, nrow=1)
    out <- as.data.frame(out)
    colnames(out) <- paste("RefQtles", qtles, sep=".")
  } else {
    qtles.ht <- args.list$qtles.ht
    ht.vector <- unlist(lapply(obj$data, function(x) x$height))
 
    id <- match(qtles.ht, ht.vector)
    which.na <- which(is.na(id))

    if(length(which.na) == 0) {
      all.ref <- lapply(obj$data[id], function(x) x$sp.pts$dBZ)
      out <- unlist(lapply(all.ref, quantile, probs= qtles/100))
      first.name <- rep(paste("RefQtles", qtles, sep="."), length(qtles.ht))
      last.name <- paste("ht", rep(qtles.ht, each=length(qtles)), sep=".")
      names(out) <- paste(first.name, last.name, sep=".")
    } else {
      all.ref <- lapply(obj$data[id[-which.na]], function(x) x$sp.pts$dBZ)

      out1 <- unlist(lapply(all.ref, quantile, probs= qtles/100))
      first.name <- rep(paste("RefQtles", qtles, sep="."), 
        length(qtles.ht[-which.na]))
      last.name <- paste("ht", rep(qtles.ht[-which.na], each=length(qtles)), 
        sep=".")
      names(out1) <- paste(first.name, last.name, sep=".")

      out2 <- rep(NA, times=length(which.na)*length(qtles.ht[which.na]))
      first.name <- rep(paste("RefQtles", qtles, sep="."), 
        length(qtles.ht[which.na]))
      last.name <- paste("ht", rep(qtles.ht[which.na], each=length(qtles)), 
        sep=".")
      names(out2) <- paste(first.name, last.name, sep=".")
      out <- c(out1, out2)
    }
  }

  data.frame(t(unlist(out)))
}

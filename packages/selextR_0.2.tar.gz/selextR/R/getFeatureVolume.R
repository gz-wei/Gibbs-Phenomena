# IBM Confidential
# OCO Source Materials
# 5747-SM3
# © Copyright IBM Corp. 1992, 1993
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#
#' Extract volume
#' 
#' Extract volume of a storm centroid.
#'
#' @param obj An object of class storm
#' @param ... Unused for now.
#'
#' @details This extracts the size of the 3-D storm in pixels.
#'
#' @export
#' @author Vik Gopal
#'
#' @return A vector of length 1 with the size of the storm.

getFeatureVolume <- function(obj, ...) {
  ht.vector <- unlist(lapply(obj$data, function(x) x$height))
 
  vols <- sum(getFeaturePlanarArea(obj, height=ht.vector), na.rm=TRUE)

  vols <- matrix(vols, nrow=1)
  vols <- as.data.frame(vols)
  colnames(vols) <- "Volume"
  vols
}

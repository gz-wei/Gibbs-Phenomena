# IBM Confidential
# OCO Source Materials
# 5747-SM3
# © Copyright IBM Corp. 1992, 1993
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#
#' List features
#' 
#' List features that can be extracted with package.
#'
#' @param obj An object of class character
#' @param ... Unused for now.
#'
#' @details This lists the available features that can be extracted using the 
#' getFeatures function set.
#'
#' @method getFeatures character
#'
#' @export
#' @author Vik Gopal
#'
#' @return A vector containing all functions that are of the form 
#' getFeaturesxxx.

getFeatures.character <- function(obj, ...) {

  if(obj == "list")
    ls("package:selextR", pattern="getFeature[A-Z]") else 
    print("Use getFeatures('list') to list all possible features")
}

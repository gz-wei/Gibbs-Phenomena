# IBM Confidential
# OCO Source Materials
# 5747-SM3
# © Copyright IBM Corp. 1992, 1993
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#
#' Extract features
#' 
#' Extract features for a storm object.
#'
#' @param obj An object of class storm
#' @param features A character vector of features to be extracted. If it is
#' equal to "list", then all functions in the package with "getFeaturexxx" are
#' listed.
#' @param ... Unused for now.
#'
#' @details This extracts the specified features for a single storm object.
#'
#' @method getFeatures storm
#'
#' @export
#' @author Vik Gopal
#'
#' @examples 
#' \dontrun{start.time <- "2011-05-20 07:09:00"}
#' \dontrun{end.time <- "2011-05-20 07:11:00"}
#' \dontrun{rbclientR(start.time, end.time, out.file='demo.json')}
#' \dontrun{scans <- createSelexScanList('demo.json')}
#' \dontrun{stormDetectionR(json.file='demo.json', ref.thresh=35, size.thresh=1000, out.file='demo.csv')}
#' \dontrun{storm.stats <- readStormStats('demo.csv.stats')}
#' \dontrun{storm.objs <- readStormObjects('demo.csv')}
#' \dontrun{storm.list<- createStormList(storm.objs, scans, storm.stats)}
#' \dontrun{storm.track <- storms[c(2,5,7,9,10,13,15)]}
#' \dontrun{traj.obj <- getTrajectory(storm.track, centroid="ref")}
#'
#' @return A vector containing the sizes at the specified heights. It will
#' contain an NA  if there is no data for that height.

getFeatures.storm <- function(obj, features, ...) {

  res <- data.frame(timestamp=obj$timestamp)

  for(f in features) {
    fn.name <- paste("getFeature", f, sep="")
    fn.tmp <- match.fun(fn.name)
    res <- cbind(res, fn.tmp(obj, ...))
  }
  
  res
}

# IBM Confidential
# OCO Source Materials
# 5747-SM3
# © Copyright IBM Corp. 1992, 1993
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#
#' Extract features
#' 
#' Extract features for a stormList or stormTrack object.
#'
#' @aliases getFeatures.stormTrack
#'
#' @param obj An object of class stormList or stormTrack
#' @param features A character vector of features to be extracted. If it is
#' equal to "list", then all functions in the package with "getFeaturexxx" are
#' listed.
#' @param ... This will contain arguments that will be passed to the individual
#' getFeature functions, e.g. height for getFeaturePlanarArea.
#'
#' @details This extracts the specified features for a stormList or stormTrack 
#' object.
#'
#' @method getFeatures stormList
#'
#' @export
#' @author Vik Gopal
#'
#' @examples 
#' \dontrun{start.time <- "2011-05-20 07:09:00"}
#' \dontrun{end.time <- "2011-05-20 07:11:00"}
#' \dontrun{rbclientR(start.time, end.time, out.file='demo.json')}
#' \dontrun{scans <- createSelexScanList('demo.json')}
#' \dontrun{stormDetectionR(json.file='demo.json', ref.thresh=35, size.thresh=1000, out.file='demo.csv')}
#' \dontrun{storm.stats <- readStormStats('demo.csv.stats')}
#' \dontrun{storm.objs <- readStormObjects('demo.csv')}
#' \dontrun{storm.list<- createStormList(storm.objs, scans, storm.stats)}
#' \dontrun{storm.track <- storms[c(2,5,7,9,10,13,15)]}
#' \dontrun{traj.obj <- getTrajectory(storm.track, centroid="ref")}
#'
#' @return A vector containing the sizes at the specified heights. It will
#' contain an NA  if there is no data for that height.

getFeatures.stormList <- function(obj, features, ...) {
  args.list <- list(...)

  if("Rainfall" %in% features) {
    if("cdom.server" %in% names(args.list)) 
      cdom.server <- args.list$cdom.server else
      stop("cdom.server needs to be named and specified\n")

    non.rain <- features[!(features == "Rainfall")]
    out <- ldply(obj, getFeatures, features=non.rain, ...)

    out.area <- ldply(obj, getFeatures, features="AreaOverlap", stations=TRUE)
    stns.id <- apply(out.area[,-(1:3)], 2, function(x) any(x))
    stns.id <- names(stns.id)[which(stns.id == TRUE)]
    stns.id <- as.numeric(substring(stns.id, 3))

    rain.data <- getFeatureRainfall(obj, stns.id, cdom.server)
    out2 <- merge(out, rain.data, by="timestamp")
    
  } else 
    out2 <- ldply(obj, getFeatures, features=features, ...)
  out2
}

# IBM Confidential
# OCO Source Materials
# 5747-SM3
# © Copyright IBM Corp. 1992, 1993
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#
#' Extract features
#' 
#' Extract features for a storm or stormTrack object.
#'
#' @param obj An object of class storm or stormTrack.
#' @param ... Unused for now.
#'
#' @details This extracts the specified features for a single storm object.
#'
#' @export
#' @author Vik Gopal
#'
#' @return Returns whatever the specific method returns.

getFeatures <- function(obj, ...) {
  UseMethod("getFeatures")
}

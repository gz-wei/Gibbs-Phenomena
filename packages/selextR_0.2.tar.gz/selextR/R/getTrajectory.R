# IBM Confidential
# OCO Source Materials
# 5747-SM3
# © Copyright IBM Corp. 1992, 1993
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#
#' Extract trajectory 
#' 
#' Create a trajectory object from a stormTrack
#'
#' @param obj An object of class stormTrack.
#' @param height The trajectory height to extract; determines the height
#' centroids to be extracted. If set to NA, then the overall 3-D centroid is 
#' used instead.
#' @param centroid This specifies the centroid type to be used. It should be one
#' of either "raw" or "ref". The latter instructs the function to use the
#' reflectivity weighted centroid. If unspecified, the function will use the raw
#' option.
#' @param ... Unused for now.
#'
#' @details This extracts the coordinates of the centroids of the storm cells in
#' the timestamps.
#'
#' @export
#' @author Vik Gopal
#'
#' @examples 
#' \dontrun{start.time <- "2011-05-20 07:09:00"}
#' \dontrun{end.time <- "2011-05-20 07:11:00"}
#' \dontrun{rbclientR(start.time, end.time, out.file='demo.json')}
#' \dontrun{scans <- createSelexScanList('demo.json')}
#' \dontrun{stormDetectionR(json.file='demo.json', ref.thresh=35, size.thresh=1000, out.file='demo.csv')}
#' \dontrun{storm.stats <- readStormStats('demo.csv.stats')}
#' \dontrun{storm.objs <- readStormObjects('demo.csv')}
#' \dontrun{storm.list<- createStormList(storm.objs, scans, storm.stats)}
#' \dontrun{storm.track <- storms[c(2,5,7,9,10,13,15)]}
#' \dontrun{traj.obj <- getTrajectory(storm.track, centroid="ref")}
#'
#' @return An object of class "traj", that can be plotted. The individual
#' components in this object are: coordinates, height, smoothed, centroid.type and
#' velocity. 'velocity' contains a data-frame with u, v, distance and speed
#' components in km/h. 'height' indicates the height of the centroids used.
#' 'centroid.type' indicates if the reflectivity weighted centroids had been
#' used. 

getTrajectory <- function(obj, height=1, centroid=c("raw", "ref"), ...) {

  centroid <- match.arg(centroid, c("raw", "ref"))

  # Obtain centroid information
  if(!is.na(height)) {
    if(centroid == "raw") {
      out <- ldply(obj, function(w) data.frame(timestamp=w$timestamp,
	x=w$data[[as.character(height)]]$stats[,paste('Ref.wt.centroid.x',height,sep='')],
	y=w$data[[as.character(height)]]$stats[,paste('Ref.wt.centroid.y',height,sep='')],
        z=height))
    } else {
      out <- ldply(obj, function(w) data.frame(timestamp=w$timestamp,
	x=w$data[[as.character(height)]]$stats[ , paste('Centroid.x',height,sep='')],
	y=w$data[[as.character(height)]]$stats[,paste('Centroid.y',height,sep='')], 
        z=height))
    }
  } else {
    if(centroid=="raw") {
      out <- ldply(obj, function(w) data.frame(timestamp=w$timestamp,
	x=w$stats[,'Centroid.x'], y=w$stats[,'Centroid.y'], 
	z=w$stats[,'Centroid.z']))
    } else {
      out <- ldply(obj, function(w) data.frame(timestamp=w$timestamp,
	x=w$stats[,'Ref.wt.centroid.x'], y=w$stats[,'Ref.wt.centroid.y'],
	z=w$stats[,'Ref.wt.centroid.z']))
    }
  }

  # Obtain velocity information
  u <- diff(out$x)
  v <- diff(out$y)
  distance <- sqrt(u^2 + v^2)
  time.diff <- difftime(out$timestamp[-1],
    out$timestamp[-length(out$timestamp)], units="hours")
  speed <- distance / as.vector(time.diff)
  velocity = data.frame(start=out$timestamp[-length(out$timestamp)],
    end=out$timestamp[-1], u=u/1000, v=v/1000,
    distance=distance/1000, speed=speed/1000)

  out.list <- list(coordinates=out[,-1], height=height, centroid.type=centroid, 
    velocity=velocity, proj4string=proj4string(obj[[1]]$data[[1]]$sp.pts))

  class(out.list) <- "trajectory"
  out.list
}


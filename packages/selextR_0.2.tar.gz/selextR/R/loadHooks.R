.onAttach <- function(libname, pkgname) {
  check <- grep("nea", Sys.info()["nodename"])
  if(length(check) > 0) {
    cat("JDA platform detected!\n")
    cat("REMEMBER TO RUN THE FOLLOWING TWO COMMANDS BEFORE PLOTTING:\n")
    cat("library(Cairo)\n")
    cat("CairoX11()\n")
    set_Polypath(FALSE)
  }
}

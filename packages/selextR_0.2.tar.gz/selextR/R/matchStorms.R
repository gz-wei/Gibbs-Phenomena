# IBM Confidential
# OCO Source Materials
# 5747-SM3
# © Copyright IBM Corp. 1992, 1993
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#
#' Match storms
#' 
#' Matches storms in a stormList from timestamp to timestamp.
#'
#' @param storm.list An object of class stormList.
#'
#' @export
#' @author Vik Gopal
#'
#' @details This function will iterate over pairs of sequential timestamps to
#' match storms, and return a list indicating the storms that form tracks. A '*'
#' indicates either a birth or a death.
#'
#' @return Returns a list that contains information on storms that make up
#' tracks.

matchStorms <- function(storm.list) {
  storm.summary <- summary(storm.list)
  tstamps <- sort(unique(storm.summary$timestamp), decreasing=FALSE)
  
  num.tstamps <- length(tstamps)
  tstamp.ids <- rep(1:num.tstamps, table(storm.summary$timestamp))

  track.info <- NULL
  for(ii in 1:(num.tstamps-1)){
    cat(paste("Working on timestamps", tstamps[ii], "and", tstamps[ii+1], "\n",
      sep=" "))

    id.1 <- which(tstamp.ids == ii)
    id.2 <- which(tstamp.ids == ii+1)
    
    out.dist <- matchStormListsDistance(storm.list[id.1], storm.list[id.2])
    out.area <- matchStormListsArea(storm.list[id.1], storm.list[id.2])
    out.dist.2 <- matchStormListsDistance2(storm.list[id.1], storm.list[id.2])
    out <- out.dist + out.area + out.dist.2
    colnames(out) <- id.1
    rownames(out) <- id.2
    track.info <- updateTrackInfo(track.info, out)
  } 
  
  track.info <- processTrackInfo(track.info)
  track.info
}

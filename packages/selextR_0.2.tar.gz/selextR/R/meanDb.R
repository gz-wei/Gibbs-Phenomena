# IBM Confidential
# OCO Source Materials
# 5747-SM3
# © Copyright IBM Corp. 1992, 1993
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#
#' Compute mean of decibel values 
#' 
#' Taking the mean of decibel values (should?) be done by converting back to the
#' original scale first, taking the mean, and then transforming back to decibel
#' values.
#'
#' @param vec1 Vector of values in decibel scale.
#'
#' @examples
#' meanDb(c(35, 55, 58))
#'
#' @export
#' @author Vik Gopal
#'
#' @return Returns a numeric scalar on the decibel scale.

meanDb <- function(vec1) {
  vec1 <- 10^(vec1/10)
  vec1 <- mean(vec1)
  10*log10(vec1)
}

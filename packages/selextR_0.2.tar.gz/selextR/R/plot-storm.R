# IBM Confidential
# OCO Source Materials
# 5747-SM3
# © Copyright IBM Corp. 1992, 1993
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#
#' Plot a storm object
#' 
#' Plot a storm object.
#'
#' @param x An object of class storm.
#' @param y This is unused here.
#' @param boundaries Logical value, indicating if country boundaries should be
#' plotted or not.
#' @param heights A vector of heights to be plotted.
#' @param convex.hull Logical argument, indicating if the convex hull of the
#' storm should be plotted, or if the actual polygon boundary should be plotted.
#' @param ... Unused for now.
#'
#' @method plot storm
#'
#' @examples 
#' \dontrun{start.time <- "2011-05-20 07:09:00"}
#' \dontrun{end.time <- "2011-05-20 07:11:00"}
#' \dontrun{rbclientR(start.time, end.time, out.file='demo.json')}
#' \dontrun{scans <- createSelexScanList('demo.json')}
#' \dontrun{stormDetectionR(json.file='demo.json', ref.thresh=35, size.thresh=1000, out.file='demo.csv')}
#' \dontrun{storm.stats <- readStormStats('demo.csv.stats')}
#' \dontrun{storm.objs <- readStormObjects('demo.csv')}
#' \dontrun{storm.list<- createStormList(storm.objs, scans, storm.stats)}
#' \dontrun{plot(storm.list, height=2)}
#' \dontrun{plot(storm.list, height=2, convex.hull=TRUE)}
#'
#' @export
#' @author Vik Gopal
#'
#' @return Nothing returned.

plot.storm <- function(x, y=NULL, boundaries=FALSE, heights,
  convex.hull = FALSE, ...) {

  avail.heights <- laply(x$data, function(x) x$height)
  if(!missing(heights))
    plot.heights <- intersect(avail.heights, heights) else
    plot.heights <- avail.heights
 
  if(length(plot.heights) == 0)
    stop("None of those requested heights present\n")

  args1 <- names(as.list(match.call()[-1]))
  if(!("xlim" %in% args1))
    xlim <- c(-70000, 170000) else
    xlim <- eval(as.list(match.call())["xlim"][[1]])
  if(!("ylim" %in% args1))
    ylim <- c(-75000, 150000) else
    ylim <- eval(as.list(match.call())["ylim"][[1]])

  if(length(plot.heights) <= 2)
    par(mfrow=c(1,2)) else
  if(length(plot.heights) <= 4)
    par(mfrow=c(2,2)) else
  if(length(plot.heights) <= 6)
    par(mfrow=c(2,3)) else
  if(length(plot.heights) <= 8)
    par(mfrow=c(2,4)) else
    stop("Too many heights to plot\n")
  
  for(height in plot.heights) {
    if(boundaries) {
      plot(sgBd, axes=TRUE, xlim=xlim, ylim=ylim)
      plot(inBd, add=TRUE)
      plot(myBd, add=TRUE)
    } else
      plot(sgBd, axes=TRUE, xlim=xlim, ylim=ylim, border=NA)

    plot(extractStormOutline(x, height=height, convex.hull=convex.hull),
      add=TRUE, col='red', border='orange')
    title(paste("Storm objects @", height, "km", sep=""))
  }
}

# IBM Confidential
# OCO Source Materials
# 5747-SM3
# © Copyright IBM Corp. 1992, 1993
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#
#' Plot a predicted storm
#' 
#' Plot a stormPredicted object.
#'
#' @param x An object of class stormPredicted.
#' @param y This can be left empty, or can be an object of class `storm'.
#' @param boundaries Logical value, indicating if country boundaries should be
#' plotted or not.
#' @param height The height of the storm objects to be plotted
#' @param ... Unused for now. Can contain xlim and ylim though.
#'
#' @method plot stormPredicted
#'
#' @export
#' @author Vik Gopal
#'
#' @return Nothing returned.

plot.stormPredicted <- function(x, y=NULL, boundaries=FALSE, height=1, ...) {
  # Work on case where y is null first. So we only want to visualise the
  # predicted storm at a certain height.

  hts <- laply(x$data, function(z) z$height)
  if(!height %in% hts)
    stop(paste("No storms found at height of", height, "km.", sep=" "))
  id <- match(height, hts)
  storm.poly <- x$data[[id]]$ellipse
  ref.grid <- x$data[[id]]$reflectivity

  args.list <- list(...)
  args1 <- names(as.list(match.call()[-1]))
  if(!("xlim" %in% args1))
    xlim <- c(-70000, 170000) else
    xlim <- eval(as.list(match.call())["xlim"][[1]])
  if(!("ylim" %in% args1))
    ylim <- c(-75000, 150000) else
    ylim <- eval(as.list(match.call())["ylim"][[1]])

  if(is.null(y)) {
    storm.poly.list <- list("sp.polygons", storm.poly, lwd=2, col='blue',
      first=TRUE)
    if(boundaries) {
      singList <- list("sp.polygons", sgBd)
      myList <- list("sp.polygons", myBd)
      inList <- list("sp.polygons", inBd)
      sp.layout.list <- list(singList, myList, inList, storm.poly.list)
    } else {
      sp.layout.list <- storm.poly.list
    }

    colorPalette1 <- rev(rainbow(32, start=5/6, end=3/6, alpha=0.8))
    at.points <- seq(from=0, to=75, length=33)

    print(spplot(ref.grid, 'dBZ', scales=list(draw=TRUE),
	 sp.layout=sp.layout.list,
	 at=at.points, col.regions=colorPalette1,
	 main=paste(x$timestamp, " UTC @", height, "km", sep=""), xlim=xlim, 
	 ylim=ylim))

  } else {
    if(class(y) != "storm")
      stop("Object y should be of class `storm'\n")

    if(boundaries) {
      plot(sgBd, axes=TRUE, xlim=xlim, ylim=ylim)
      plot(inBd, add=TRUE)
      plot(myBd, add=TRUE)
    } else {
      plot(sgBd, axes=TRUE, xlim=xlim, ylim=ylim, border=NA)
    }
    
    if("convex.hull" %in% names(args.list)) {
      convex.hull <- args.list[["convex.hull"]]
    } else {
      convex.hull <- FALSE
    }

    observed.storm.poly <- extractStormOutline(y, height=height, 
      convex.hull=convex.hull)

    plot(storm.poly, lwd=2, border='blue', add=TRUE)
    plot(observed.storm.poly, lwd=2, border='red', add=TRUE)
  }
}

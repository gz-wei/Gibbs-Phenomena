# IBM Confidential
# OCO Source Materials
# 5747-SM3
# © Copyright IBM Corp. 1992, 1993
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#
#' Plot a storm track
#' 
#' Plot a stormTrack object.
#'
#' @param x An object of class stormTrack.
#' @param y This is unused here.
#' @param boundaries Logical value, indicating if country boundaries should be
#' plotted or not.
#' @param height The height of the storm objects to be plotted
#' @param zoom Zoom level of plot. The default value of 1 is the minimal plot
#' that shows all hte storm tracks. Values larger than 1 will show more of the SEA
#' region.
#' @param alpha Transparency level of the shade of grey to be used.
#' @param bw This is the bandwidth for the smoothing of the trajectory.
#' @param ... Use this to add arguments to the plot.trajectory method, e.g.
#' lwd=2.
#'
#' @method plot stormTrack
#'
#' @examples
#' \dontrun{start.time <- "2011-05-20 07:09:00"}
#' \dontrun{end.time <- "2011-05-20 07:11:00"}
#' \dontrun{rbclientR(start.time, end.time, out.file='demo.json')}
#' \dontrun{scans <- createSelexScanList('demo.json')}
#' \dontrun{stormDetectionR(json.file='demo.json', ref.thresh=35, size.thresh=1000, out.file='demo.csv')}
#' \dontrun{storm.stats <- readStormStats('demo.csv.stats')}
#' \dontrun{storm.objs <- readStormObjects('demo.csv')}
#' \dontrun{storm.list<- createStormList(storm.objs, scans, storm.stats)}
#' \dontrun{storm.track <- storms[c(2,5,7,9,10,13,15)]}
#' \dontrun{plot(storm.track)}
#'
#' @export
#' @author Vik Gopal
#'
#' @return Nothing returned.

plot.stormTrack <- function(x, y=NULL, boundaries=FALSE, height=1, 
  zoom = 1, alpha=25, bw=20, ...) {

  s2 <- llply(x, extractStormOutline, height=height, convex.hull=TRUE)

  x.min <- min(sapply(s2, function(x) bbox(x)["x","min"]))
  x.max <- max(sapply(s2, function(x) bbox(x)["x","max"]))
  y.min <- min(sapply(s2, function(x) bbox(x)["y","min"]))
  y.max <- max(sapply(s2, function(x) bbox(x)["y","max"]))
  xlims <- c(x.min, x.max)
  ylims <- c(y.min, y.max)

  orig.means <- c(mean(xlims), mean(ylims))
  orig.diff <- c(x.max-x.min, y.max-y.min)
  xlims <- c(orig.means[1]-zoom*orig.diff[1]/2,
    orig.means[1]+zoom*orig.diff[1]/2)
  ylims <- c(orig.means[2]-zoom*orig.diff[2]/2,
    orig.means[2]+zoom*orig.diff[2]/2)

  plot(s2[[1]], border=NA, axes=TRUE, xlim=xlims, ylim=ylims)

  greys.seq <- seq(from=1, to=0, length=length(s2))
  col.array <- col2rgb(grey(greys.seq))

  for(i in 1:length(s2)) {
    z <- s2[[i]]
    plot(z, col=rgb(col.array[1,i], col.array[2,i], col.array[3,i], 
      alpha, maxColorValue=255), lty=2, add=TRUE)
  }

  # Plot smoothed trajectory and centroids
  traj.obj <- getTrajectory(x, height=height, "ref")
  plot(traj.obj, bw=bw, add=TRUE, ...)
  centroid.obj <- SpatialPoints(traj.obj$coordinates[,c("x","y")],
    proj4string=CRS(traj.obj$proj4string))
  plot(centroid.obj, add=TRUE, col="orange")

  # Plot boundaries of countries if desired.
  if(boundaries) {
    plot(sgBd, add=TRUE)
    plot(inBd, add=TRUE)
    plot(myBd, add=TRUE)
  }

  all.times <- sapply(x, function(x) as.character(x$timestamp))
  start.time <- all.times[1]
  end.time <- all.times[length(all.times)]
  title(paste("Start time:\t", start.time, "\n", "End time:\t", end.time))
}

# IBM Confidential
# OCO Source Materials
# 5747-SM3
# © Copyright IBM Corp. 1992, 1993
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#
#' Plot a list of tracks
#' 
#' Plot a lines indicating tracks of storms 
#'
#' @param track.info An object returned by matchStorms
#' @param storm.list A list of storms whose ids are referred to in the
#' track.info object.
#' @param ... xlim and ylim can be passed to the plot device here.
#'
#' @details This is a basic function for now. It's not that pretty, but it
#' allows the analyst to identify tracks for further study.
#'
#' @examples 
#' \dontrun{start.time <- "2011-05-20 07:09:00"}
#'
#' @export
#' @author Vik Gopal
#'
#' @return Nothing returned. Only plot is shown.

plotTrackInfo <- function(track.info, storm.list, ...) {
  id.a <- laply(track.info, length)
  id.a <- rep(1:length(track.info), times=id.a)
  id.b <- unlist(llply(track.info, function(x) paste("-", 1:length(x), 
    sep="")))

  label.id <- paste(id.a, id.b, sep="")

  args.list <- list(...)
  if(!("xlim" %in% names(args.list)))
    xlim <- c(-70000, 170000) else
    xlim <- args.list$xlim
  if(!("ylim" %in% names(args.list)))
    ylim <- c(-75000, 150000) else
    ylim <- args.list$ylim

  plot(sgBd, axes=TRUE, xlim=xlim, ylim=ylim)
  plot(inBd, add=TRUE)
  plot(myBd, add=TRUE)

  unlist.tracks <- unlist(track.info)
  for(t1 in 1:length(unlist.tracks)) {
    l1 <- trackToLines(unlist.tracks[t1], storm.list, label.id[t1])
    lines(l1, lwd=2, col='red')
    if(strsplit(label.id[t1], "-")[[1]][2] == "1") {
      pts <- as(l1, "SpatialPoints")
      start <- coordinates(pts)[1,]
      end <- coordinates(pts)[length(pts),]
      text(start[1], start[2], labels=paste("S.",label.id[t1],sep=""), cex=0.8, 
        font=2, col='blue')
      text(end[1], end[2], labels=paste("E.",label.id[t1],sep=""), cex=0.8, 
        font=2, col='blue')
    }
  }
  
}

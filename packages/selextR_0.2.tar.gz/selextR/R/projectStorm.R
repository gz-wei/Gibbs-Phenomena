# IBM Confidential
# OCO Source Materials
# 5747-SM3
# © Copyright IBM Corp. 1992, 1993
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#
#' Project a storm object
#' 
#' Project all heights of a storm onto a single SpatialPolygons object.
#'
#' @param storm.obj An object of class "storm".
#'
#' @details This allows one to project all the heights of a storm onto one layer.
#'
#' @export
#' @author Vik Gopal
#'
#' @return An object of class SpatialPolygons.

projectStorm <- function(storm.obj) {
  all.pts <- ldply(storm.obj$data, function(x) coordinates(x$sp.pts))[,-1]
  all.pts <- SpatialPoints(all.pts,
    CRS(proj4string(storm.obj$data[[1]]$sp.pts)))

  gConvexHull(all.pts)
}

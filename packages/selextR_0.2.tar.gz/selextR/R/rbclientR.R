# IBM Confidential
# OCO Source Materials
# 5747-SM3
# © Copyright IBM Corp. 1992, 1993
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#
#' R version of rbclient
#' 
#' This is an R wrapper for calling the Python rbclient code.
#'
#' @param start.time Starting time for query to be sent to rbdataserver. It
#' should be a character vector of the form "yyyy-mm-dd HH:MM:SS".
#' @param end.time Ending time for query to be sent to rbdataserver. It
#' should be a character vector of the form "yyyy-mm-dd HH:MM:SS".
#' @param host.name IP address or hostname of machine on which rbdataserver is
#' running. It should be a character vector of length 1.
#' @param port.num The port number on which rbdataserver is running. It should be
#' an integer.
#' @param path.to.rbclient The full path to where the rbclient.py resides. It is
#' advisable to keep this as the local copy of the RTC repository.
#' @param prod.type The product type to extract from the radar product directory.
#' @param out.format The output format of products extracted.
#' @param out.file The name of the output file to write to.
#' @param time.off The UTC time offset to search for. This parameter should be a
#' string in minutes after UTC. For example, Singapore should have "+480"
#'
#' @details This is an R wrapper to the codes written by Stuart Siegel. The
#' Python infrastructure for decoding Selex products has to be set up first before
#' this function can be used. In other words, rbdataserver has to be up and
#' running.
#'
#' @export
#' @author Stu Siegel,
#' Vik Gopal
#'
#' @examples 
#' \dontrun{start.time <- "2011-05-20 07:09:00"}
#' \dontrun{end.time <- "2011-05-20 07:11:00"}
#' \dontrun{rbclientR(start.time, end.time)}
#' \dontrun{## for extracting more than one product at a time}
#' \dontrun{rbclientR(start.time, end.time, prod.type="V.cappi W.cappi")}
#'
#' @return Returns nothing. Typically, it writes to a json file that has to be read
#' again.

rbclientR <- function(start.time, end.time, host.name = 'IBM-R85PPXT', port.num = 9995,
path.to.rbclient = "C:\\Documents and Settings\\Administrator\\My Documents\\NEA\\heavyRainGust\\NEA\\cdom\\radar",
  prod.type="dBZ.cappi", out.format="j", out.file="tmp.json", time.off=0) {
  cat("\nRunning Stu's code... ")

  os <- Sys.info()['sysname']
  if(os == "Windows") {
    cmd2 <- paste('python "', path.to.rbclient, '\\rbclient.py" -H ', host.name, " -p ", 
	   port.num, ' -m "', start.time, '" -M "', end.time, '" -t ', prod.type, " -d ./ -f ", 
	   out.file, " -u ", time.off, " --format ", out.format, " --itpattern", sep="")
  } else {
    cmd2 <- paste('python "', path.to.rbclient, '/rbclient.py" -H ', host.name, " -p ", 
	   port.num, ' -m "', start.time, '" -M "', end.time, '" -t ', prod.type, " -d ./ -f ", 
	   out.file, " -u ", time.off, " --format ", out.format, " --itpattern", sep="")
  }
  system(cmd2)
  cat(" Done with Stu's code.\n")
}

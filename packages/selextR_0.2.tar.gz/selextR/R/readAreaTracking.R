# IBM Confidential
# OCO Source Materials
# 5747-SM3
# © Copyright IBM Corp. 1992, 1993
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#
#' Process area tracking output.
#' 
#' This is a function for reading in and processing the output from
#' areaTrackingR.
#'
#' @param algo.params A json file containing the parameters for the area
#' tracking algorithm.
#' @param area.tracking.file The file that was output by areaTrackingR
#' @param scan.list The object of class SelexScanList corresponding to the
#' scans that were put through the area tracking algorithm.
#' 
#' @details This applies the area-tracking algorithm to the sequence of scans in
#' the json file. The assumption here is that the radar information is on a 480
#' by 480 grid, and that there are 5 heights!
#'
#' @export
#' @author Sayan Ranu, Prithu Banerjee, 
#' Vik Gopal
#'
#' @examples 
#'
#' @return Returns a list that contains the output from areaTrackingR.

readAreaTracking <- function(algo.params, area.tracking.file, scan.list) {
  params <- fromJSON(file=algo.params)
  box.size <- params[[2]]
  num.lines.per.ht <- 480/box.size
  grid.topo <- getGridTopology(scan.list[[1]]$data)
  grid.topo.2 <- GridTopology(grid.topo@cellcentre.offset, 
    grid.topo@cellsize*box.size, grid.topo@cells.dim/box.size)
  area.track.grid <- SpatialGrid(grid.topo.2, CRS(svy21Proj))

  timestamps <- unique(summary(scan.list)[,1])
  lines <- readLines(area.tracking.file)
  out <- NULL

  for(ii in 1:(length(timestamps)-1)) {
    tmp.lines.1 <- lines[((ii-1)*5*num.lines.per.ht + 1):
      (ii*5*num.lines.per.ht)]
    for(jj in 1:5) {
      tmp.lines.2 <- tmp.lines.1[((jj-1)*num.lines.per.ht + 1):
	(jj*num.lines.per.ht)]

      tmp <- ldply(lapply(tmp.lines.2, processLine))
      out.elt <- SpatialGridDataFrame(area.track.grid, tmp)
      out <- c(out, out.elt)
      names(out)[length(out)] <- paste(timestamps[ii], "-", jj, sep="")
    }
  }
  out

}

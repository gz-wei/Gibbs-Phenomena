# IBM Confidential
# OCO Source Materials
# 5747-SM3
# © Copyright IBM Corp. 1992, 1993
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#
#' Country boundaries
#' 
#' Documents the country boundaries included with this package.
#'
#' @name sgBd
#' @aliases inBd myBd stns svy21Proj latLongProj
#' @docType data
#'
#' @format inBd contains the boundary of Indonesia, myBd contains West Malaysia
#' and sgBd contains Singapore. All use the svy21 projection system. stns
#' contains the observation stations on Singapore. It also contains the
#' proj4string for svy21 (svy21Proj) and lat-long (latLongProj).
#'
NULL

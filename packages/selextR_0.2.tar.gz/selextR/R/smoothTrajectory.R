# IBM Confidential
# OCO Source Materials
# 5747-SM3
# © Copyright IBM Corp. 1992, 1993
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#
#' Smooth a trajectory
#' 
#' Smooth a trajectory object
#'
#' @param traj.obj An object of class trajectory
#' @param bw Bandwidth for the smoothing to be done. If this is set to 0, then
#' the points are simply joined together.
#'
#' @details This function smooths the coordinates in a stormTrack object.
#'
#' @export
#' @author Vik Gopal
#'
#' @examples 
#' \dontrun{start.time <- "2011-05-20 07:09:00"}
#' \dontrun{end.time <- "2011-05-20 07:11:00"}
#' \dontrun{rbclientR(start.time, end.time, out.file='demo.json')}
#' \dontrun{scans <- createSelexScanList('demo.json')}
#' \dontrun{stormDetectionR(json.file='demo.json', ref.thresh=35, size.thresh=1000, out.file='demo.csv')}
#' \dontrun{storm.stats <- readStormStats('demo.csv.stats')}
#' \dontrun{storm.objs <- readStormObjects('demo.csv')}
#' \dontrun{storm.list<- createStormList(storm.objs, scans, storm.stats)}
#' \dontrun{storm.track <- storms[c(2,5,7,9,10,13,15)]}
#' \dontrun{traj.obj <- getTrajectory(storm.track, centroid="ref")}
#' \dontrun{plot(smoothTrajectory(traj.obj, 0), axes=TRUE)}
#'
#' @return Returns an object of class SpatialLines.

smoothTrajectory <- function(traj.obj, bw=20) {
  if(bw == 0){
    l1 <- traj.obj$coordinates[, c("x", "y")]
    l1 <- Line(l1)
    l1 <- Lines(list(l1), "traj")
    l1 <- SpatialLines(list(l1), proj4string=CRS(traj.obj$proj4string))
    return(l1)
  } 

  t1 <- as.vector(difftime(traj.obj$coordinates$timestamp[-1], 
    traj.obj$coordinates$timestamp[-nrow(traj.obj$coordinates)],
    units="mins"))
  t1 <- c(0, cumsum(t1))
  x1 <- ksmooth(t1, traj.obj$coordinates$x, "normal", bandwidth=bw)$y
  y1 <- ksmooth(t1, traj.obj$coordinates$y, "normal", bandwidth=bw)$y
  l1 <- Line(cbind(x=x1, y=y1))
  l1 <- Lines(list(l1), "traj")
  l1 <- SpatialLines(list(l1), proj4string=CRS(traj.obj$proj4string))

  return(l1)
}

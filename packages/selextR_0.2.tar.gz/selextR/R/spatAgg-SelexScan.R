# IBM Confidential
# OCO Source Materials
# 5747-SM3
# © Copyright IBM Corp. 1992, 1993
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#
#' Spatial aggregation of scan
#' 
#' Generic function for aggregating spatial measurements from a radar scan.
#'
#' @param x An object of class SelexScan.
#' @param average.over This is an integer vector of length 2. It specifies how
#' many grids in the x- and y- direction should be combined. For example, c(2,2)
#' says each cell in the new grid should contain 4 of the original grid squares.
#' @param ... Unused for now.
#'
#' @method spatAgg SelexScan
#'
#' @export
#' @author Vik Gopal
#'
#' @examples 
#' \dontrun{start.time <- "2011-05-20 07:09:00"}
#' \dontrun{end.time <- "2011-05-20 07:11:00"}
#' \dontrun{rbclientR(start.time, end.time, out.file='tmp1')}
#' \dontrun{out <- createSelexScan('tmp1')}
#' \dontrun{plot(spatAgg(out[[1]], c(5,5)))}
#' \dontrun{plot(spatAgg(out[[1]], c(10,5)), xlim=c(0, 50000), ylim=c(0, 75000))}
#'
#' @return Returns an object of class SelexScan, with the aggregated values. The 
#' grid dimensions will be modified in the data slot, as will with the spat.agg
#' slot.

spatAgg.SelexScan <- function(x, average.over=c(2,2), ...) {
  topo.org <- as.data.frame(x$data@grid)
  nrows.org <- topo.org$cells.dim[2]
  ncols.org <- topo.org$cells.dim[1]

  data.vec <- x$data@data$curPlot
  data.mat <- matrix(data.vec, nrow=nrows.org, ncol=ncols.org, byrow=TRUE)
  
  if(x$prod.type %in% c("dBZ"))
    meas.scale <- "db" else
    meas.scale <- "org"

  new.data.mat <- computeMxMeansSpatAgg(data.mat, average.over, meas.scale)
  new.data.vec <- as.vector(t(new.data.mat))
  
  topo.new <- computeNewTopo(topo.org, average.over)

  spatGrd <- SpatialGrid(grid=topo.new, CRS(proj4string(x$data)))
  spatDat <- SpatialGridDataFrame(spatGrd, data.frame(curPlot=new.data.vec))

  new.obj <- list(timestamp=x$timestamp, height=x$height, prod.type=x$prod.type,
    data=spatDat, spat.agg=average.over)
  class(new.obj) <- "SelexScan"

  new.obj
}

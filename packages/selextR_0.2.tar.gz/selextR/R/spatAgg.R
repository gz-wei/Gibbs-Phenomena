# IBM Confidential
# OCO Source Materials
# 5747-SM3
# © Copyright IBM Corp. 1992, 1993
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#
#' Spatial aggregation of scan
#' 
#' Generic function for aggregating spatial measurements from a radar scan.
#'
#' @param x An object of class SelexScan.
#' @param ... Extra arguments passed to the specific method.
#'
#' @export
#' @author Vik Gopal
#'
#' @return Returns whatever the specific method returns.
#'
#' @seealso \code{\link{spatAgg.SelexScan}}

spatAgg <- function(x, ...) {
  UseMethod("spatAgg")
}

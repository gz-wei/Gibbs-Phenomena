# IBM Confidential
# OCO Source Materials
# 5747-SM3
# © Copyright IBM Corp. 1992, 1993
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#
#' R wrapper to StormDetection
#' 
#' This is an R wrapper for calling the Java storm detection codes
#'
#' @param path.java Fully qualified path the java executable.
#' @param jvm.args The memory specification. This default is for WinXP 32-bit
#' @param algorithm The algorithm to use for storm detection. For now, it can be
#' one of 'titan' or 'scit'.
#' @param json.file The json output from \code{\link{rbclientR}}.
#' @param ref.thresh Reflectivity threshold for storm detection.
#' @param size.thresh Size threshold for storm detection.
#' @param algo.params A json file containing the parameters for the SCIT storm
#' or the convolution method detection algorithms.
#' @param out.file The output filename. There will be two files produced: One
#' will be named out.file, and the second will be named out.file + '.stats'
#' 
#' @details For now, this implements the TITAN method of detecting a storm, based
#' on a reflectivity threshold and a size threshold. The reflectity units are dBZ,
#' and the size threshold is in pixels. SCIT algorithm has been added now.
#'
#' @export
#' @author Sayan Ranu, Prithu Banerjee, 
#' Vik Gopal
#'
#' @examples 
#' \dontrun{start.time <- "2011-05-20 07:09:00"}
#' \dontrun{end.time <- "2011-05-20 07:11:00"}
#' \dontrun{rbclientR(start.time, end.time, out.file='demo.json')}
#' \dontrun{scans <- createSelexScanList('demo.json')}
#' \dontrun{stormDetectionR(json.file='demo.json', ref.thresh=35, size.thresh=1000, out.file='demo.csv')}
#' \dontrun{storm.stats <- readStormStats('demo.csv.stats')}
#' \dontrun{storm.objs <- readStormObjects('demo.csv')}
#' \dontrun{storm.list<- createStormList(storm.objs, scans, storm.stats)}
#' \dontrun{summary(storm.list)}
#'
#' @return Returns none. If it completes without error, two text files should be
#' written.

stormDetectionR <- function(path.java="\"C:\\Program Files\\IBM\\Java60\\jre\\bin\\java.exe\"",
  jvm.args="-Xss2048k", algorithm=c('titan', 'scit', 'conv'), ref.thresh=30, size.thresh=500, json.file,
  out.file="test.csv", algo.params) {

  algorithm <- match.arg(algorithm, c('titan', 'scit', 'conv'))
  jars <- c("StormDetection.jar", "commons-cli-1.2.jar",
    "jackson-all-1.9.11.jar")
  path.to.jars <- path.package("selextR")

  if(algorithm == 'titan') {
    ref.thresh.2 <- convertFromUnits(ref.thresh, "dBZ")
    if(Sys.info()['sysname'] ==  "Windows") {
      path.to.jars <- strsplit(path.to.jars, "/")[[1]]
      path.to.jars <- paste(path.to.jars, collapse="\\")
      path.to.jars <- paste(path.to.jars, "jar", jars, sep="\\")
      path.to.jars <- paste('"', path.to.jars, '"', sep="")
      path.to.jars <- paste(path.to.jars, collapse=";")
    } else {
      jvm.args <- "-Xss512m"
      path.to.jars <- paste(path.to.jars, "jar", jars, sep="/")
      path.to.jars <- paste(path.to.jars, collapse=":")
    }
    cat("\nRunning Sayan's code... \n")
    cmd2 <- paste(path.java, jvm.args, '-classpath', path.to.jars, 
	      'com.ibm.cdom.ext.util.radar.StormDetection', 
	      '-sizeThresh', size.thresh, '-valThresh', ref.thresh.2,
	      '-json', json.file, '-f', out.file, sep=" ")
    system(cmd2)
    cat("Done with Sayan's code.\n")
  } else if(algorithm == 'scit') {
    if(missing(algo.params))
      stop("A json file with the SCIT parameters must be specified.\n")
    if(!file.exists(algo.params))
      stop("Specified SCIT parameter file does not exist\n")

    if(Sys.info()['sysname'] ==  "Windows") {
      path.to.jars <- strsplit(path.to.jars, "/")[[1]]
      path.to.jars <- paste(path.to.jars, collapse="\\")
      path.to.jars <- paste(path.to.jars, "jar", jars, sep="\\")
      path.to.jars <- paste('"', path.to.jars, '"', sep="")
      path.to.jars <- paste(path.to.jars, collapse=";")
    } else {
      jvm.args <- "-Xss512m"
      path.to.jars <- paste(path.to.jars, "jar", jars, sep="/")
      path.to.jars <- paste(path.to.jars, collapse=":")
    }
    cat("\nRunning Prithu's code... \n")
    cmd2 <- paste(path.java, jvm.args, '-classpath', path.to.jars, 
	      'com.ibm.cdom.ext.util.radar.StormSCIT', 
	      '-params', algo.params,
	      '-json', json.file, '-f', out.file, sep=" ")
    system(cmd2)
    cat("Done with Prithu's code.\n")
  } else if(algorithm == 'conv') {
    if(missing(algo.params))
      stop("A json file with the convolution parameters must be specified.\n")
    if(!file.exists(algo.params))
      stop("Specified convolution parameter file does not exist\n")

    if(Sys.info()['sysname'] ==  "Windows") {
      path.to.jars <- strsplit(path.to.jars, "/")[[1]]
      path.to.jars <- paste(path.to.jars, collapse="\\")
      path.to.jars <- paste(path.to.jars, "jar", jars, sep="\\")
      path.to.jars <- paste('"', path.to.jars, '"', sep="")
      path.to.jars <- paste(path.to.jars, collapse=";")
    } else {
      jvm.args <- "-Xss512m"
      path.to.jars <- paste(path.to.jars, "jar", jars, sep="/")
      path.to.jars <- paste(path.to.jars, collapse=":")
    }
    cat("\nRunning Prithu's code... \n")
    cmd2 <- paste(path.java, jvm.args, '-classpath', path.to.jars, 
	      'com.ibm.cdom.ext.util.radar.StormConvolution', 
	      '-params', algo.params,
	      '-json', json.file, '-f', out.file, sep=" ")
    system(cmd2)
    cat("Done with Prithu's code.\n")

  }
}

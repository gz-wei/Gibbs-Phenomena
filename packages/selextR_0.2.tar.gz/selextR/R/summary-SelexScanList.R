# IBM Confidential
# OCO Source Materials
# 5747-SM3
# © Copyright IBM Corp. 1992, 1993
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#
#' Summarize info in radar scans
#' 
#' Print a summary table of the information in a SelexScanList object.
#'
#' @param object An object of class SelexScanList.
#' @param ... Unused for now.
#'
#' @method summary SelexScanList
#'
#' @examples 
#' \dontrun{start.time <- "2011-05-20 07:09:00"}
#' \dontrun{end.time <- "2011-05-20 07:11:00"}
#' \dontrun{rbclientR(start.time, end.time, out.file='tmp1')}
#' \dontrun{out <- createSelexScan('tmp1')}
#' \dontrun{summary(out)}
#'
#' @export
#' @author Vik Gopal
#'
#' @return Returns a data frame that contains the timestamps, heights and
#' product types of all the scans present.

summary.SelexScanList <- function(object, ...) {
  tstamps <- sapply(object, function(y) y$timestamp)
  heights <- sapply(object, function(y) y$height)
  prod.type <- sapply(object, function(y) y$prod.type)

  data.frame(Timestamps=tstamps, Heights=heights, Prod.type=prod.type, 
    stringsAsFactors=FALSE)
}

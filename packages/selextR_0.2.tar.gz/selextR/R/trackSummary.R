# IBM Confidential
# OCO Source Materials
# 5747-SM3
# © Copyright IBM Corp. 1992, 1993
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#
#' Summarize a track
#' 
#' Return characteristics of a track
#'
#' @param track.info An individual storm track. This would look something like
#' "*-1-4-8-12-*", which is an element of the list returned by matchStorms.
#' @param storm.list A list of storms whose ids are referred to in the
#' track.info object.
#' @param storm.period An integer for the storm period for which we have
#' radar data.
#' @param storm.label An identifier for the storm track within that collection
#' of storm tracks (see the output from matchStorms, and the labelling used in
#' plotTrackInfo.
#' @param cdom.server CDOM server from which to get rainfall data.
#'
#' @details This is a basic function for now. It is meant to be used for the
#' storm summary exercise, in conjunction with a plyr function.
#'
#' @examples 
#' \dontrun{start.time <- "2011-05-20 07:09:00"}
#'
#' @export
#' @author Vik Gopal
#'
#' @return A data frame with one row.

trackSummary <- function(track.info, storm.list, storm.period, storm.label, 
                         cdom.server="10.0.0.2") {
  ids <- unique(strsplit(track.info, "-")[[1]])
  ids <- as.numeric(ids[ids != '*'])

  storm.track <- createStormTrack(storm.list[ids])
  
  feat <- getFeatures(storm.track, c("Volume", "PlanarArea", "AreaOverlap", 
    "CentroidLoc", "MaxRef"), height=1)[,-1]
  centroid.loc <- feat[, c("Centroid.x", "Centroid.y")]

  out <- data.frame(storm.period, storm.label)

  # storm duration info
  first.letter <- substring(track.info, 1, 1)
  if(first.letter == "*")
    out$left.censor = FALSE else
    out$left.censor = TRUE

  last.letter <- substring(track.info, first=nchar(track.info))
  if(last.letter == "*")
    out$right.censor = FALSE else
    out$right.censor = TRUE

  out$storm.dur <- length(ids)*5
  
  if(length(ids) < 2) {
    out$start.loc.x <- NA
    out$start.loc.y <- NA
    out$end.loc.x <- NA
    out$end.loc.y <- NA
    out$total.distance <- NA
    out$mean.speed <- NA
    out$mean.dir <- NA
    out$max.vol <- NA
    out$max.area <- NA
    out$overlap.dur <- NA
    out$max.overlap <- NA
    out$rain.max <- NA
    out$rain.stn <- NA
    out$max.ref <- NA
    return(out)
  }

  # get start and end location
  out$start.loc.x <- centroid.loc$Centroid.x[1]
  out$start.loc.y <- centroid.loc$Centroid.y[1]
  out$end.loc.x <- centroid.loc$Centroid.x[nrow(centroid.loc)]
  out$end.loc.y <- centroid.loc$Centroid.y[nrow(centroid.loc)]

  # get distances in km
  start.to.end <- SpatialPoints(centroid.loc,
   CRS(proj4string(storm.track[[1]]$data[[1]]$sp.pts)))

  id <- cbind(2:length(storm.track), 1:(length(storm.track)-1))
  dist <- spDists(start.to.end)
  dist <-  apply(id, 1, function(x) dist[x[1], x[2]])
  
  out.sub <- ldply(storm.track, function(x) x$timestamp)
  out.sub$distance <- c(NA, dist/1000)
  colnames(out.sub)[-1] <- c("timestamp", "distance")

  out.sub$u <- c(NA, diff(centroid.loc$Centroid.x)/1000)
  out.sub$v <- c(NA, diff(centroid.loc$Centroid.y)/1000)

  keep.these <- which(out.sub$distance <= 10 & !is.na(out.sub$distance))
  out$total.distance <- sum(out.sub$distance[keep.these])

  # get speed in km/h
  num.time.periods <- length(keep.these)
  out$mean.speed <- out$total.distance * 10 / num.time.periods

  # get direction in radians
  mean.u <- mean(out.sub$u[keep.these])
  mean.v <- mean(out.sub$v[keep.these])
  out$mean.dir <- atan2(mean.v, mean.u)
  
  # get Volume in pixels
  out$max.vol <- max(feat$Volume)

  # get Area  in pixels
  out$max.area <- max(feat$PlanarArea.1)

  # get overlap duration in minutes
  out$overlap.dur <- sum(feat$AreaOverlap.proj > 0) * 5
 
  # get maximum overlap in km^2
  if(any(feat$AreaOverlap.proj > 0 )) {
    out$max.overlap <- max(feat$AreaOverlap.proj[feat$AreaOverlap.proj > 0]) 
    rain.data <- getFeatures(storm.track, "Rainfall", cdom.server=cdom.server)
    if(nrow(rain.data) > 0 ) { # there is a possibility of no records returned.
      if(ncol(rain.data) > 3) # possibility of only one station returned
	rain.data <- rain.data[ , -(1:2)] else {
	tmp <- as.data.frame(rain.data[ , -(1:2)])
	colnames(tmp) <- colnames(rain.data)[3]
	rain.data <- tmp
      }
	
      total.rain <- colSums(rain.data)
      if(any(total.rain > 0)) {
	out$rain.max <- max(total.rain)
	out$rain.stn <- names(total.rain)[which.max(total.rain)]

      } else {
	out$rain.max <- 0
	out$rain.stn <- NA
      }
    }

  } else {
    out$max.overlap <- 0
    out$rain.max <- NA
    out$rain.stn <- NA
  }

  # reflectivity info
  out$max.ref <- max(feat$MaxRef.1)

  out
}

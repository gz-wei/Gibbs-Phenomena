# IBM Confidential
# OCO Source Materials
# 5747-SM3
# © Copyright IBM Corp. 1992, 1993
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#
# Undocumented helper (anonymous) functions

#######################
# For extracting storms
#######################
# For use with ldply
rawStormToSpatialPoints <- function(raw1, selex.scan.list, storm.stats) {
  # raw1 is one whole storm object, with all the heights
  choose.scan <- sapply(selex.scan.list, function(x) x$timestamp ==
    raw1$dateTime[1])
  chosen.scans <- selex.scan.list[which(choose.scan)]

  out.list <- dlply(raw1, "z", rawStormHtToSpatialPoints, chosen.scans,
    storm.stats)

  hash.val <- digest(raw1)
  
  # Check the z-vals later (for 0-1 correctness)!!!
  sub.stats <- storm.stats[storm.stats$ID == raw1$storm.id[1], ]
  sub.stats <- sub.stats[ , -grep('[12345]', names(sub.stats))]
  sub.stats <- sub.stats[ , -c(1,2)]

  # Add the projection corrected centroid for the overall centroids. This is a
  # real hack!
  sub.stats$Centroid.x <- out.list[[1]]$stats$Centroid.x
  sub.stats$Centroid.y <- out.list[[1]]$stats$Centroid.y
  sub.stats$Ref.wt.centroid.x <- out.list[[1]]$stats$Ref.wt.centroid.x
  sub.stats$Ref.wt.centroid.y <- out.list[[1]]$stats$Ref.wt.centroid.y

  # Some clean-up to remove the additional overall centroid variables.
  for(ii in 1:length(out.list)) {
    tmp.len <- ncol(out.list[[ii]]$stats)
    out.list[[ii]]$stats <- out.list[[ii]]$stats[, -((tmp.len-3):tmp.len)]
  }

  out.list <- list(timestamp = raw1$dateTime[1], hash.val=hash.val,
    data=out.list, stats=sub.stats)
  class(out.list) <- "storm"
  out.list
}

# For use with ldply
rawStormHtToSpatialPoints <- function(raw2, chosen.scans, storm.stats) {
  # raw1 is one height of one storm object
  choose.sub.scan <- sapply(chosen.scans, function(x) x$height ==
    raw2$z[1])
  chosen.sub.scan <- chosen.scans[[which(choose.sub.scan)]]
  
  topleft.x <- coordinates(chosen.sub.scan$data[1,1])[1,1]
  topleft.y <- coordinates(chosen.sub.scan$data[1,1])[1,2]

  gridTopo <- getGridTopology(chosen.sub.scan$data)
  x.size <- gridTopo@cellsize[1]
  y.size <- gridTopo@cellsize[2]

  x.pts <- sapply(raw2$y, function(a) a*x.size + topleft.x, USE.NAMES=FALSE)
  y.pts <- sapply(raw2$x, function(a) topleft.y - a*y.size, USE.NAMES=FALSE)
  sp.pts <- SpatialPoints(cbind(x.pts, y.pts),
    CRS(proj4string(chosen.sub.scan$data)))
  sp.pts <- SpatialPointsDataFrame(sp.pts, data=data.frame(dBZ=raw2$dBZ))

  # get stats, get height, form list and return
  sub.stats <- storm.stats[storm.stats$ID == raw2$storm.id[1], ]
  c.x <- sub.stats$Centroid.x
  c.y <- sub.stats$Centroid.y
  r.c.x <- sub.stats$Ref.wt.centroid.x
  r.c.y <- sub.stats$Ref.wt.centroid.y

  sub.stats <- sub.stats[,grep(as.character(raw2$z[1]), names(sub.stats))]
  sub.stats <- sub.stats[,-grep("z", names(sub.stats))]
  tmp <- sub.stats[, grep("entroid", names(sub.stats))]
 
  sub.stats[,grep("\\.x", names(sub.stats))] <- 
    topleft.x + tmp[ , grep("y", names(tmp))]*x.size
  sub.stats[,grep("\\.y", names(sub.stats))] <- 
    topleft.y - tmp[ , grep("x", names(tmp))]*y.size

  sub.stats$Centroid.x <- topleft.x + c.y*x.size
  sub.stats$Centroid.y <- topleft.y - c.x*y.size
  sub.stats$Ref.wt.centroid.x <- topleft.x + r.c.y*x.size
  sub.stats$Ref.wt.centroid.y <- topleft.y - r.c.x*y.size

  height <- raw2$z[1]

  list(height=height, sp.pts=sp.pts, stats=sub.stats, 
    gridTopo=gridTopo)
}

######################################################
# For polygonising the SpatialPoints of a storm object
######################################################
extractStormOutline <- function(storm.obj, height, convex.hull=FALSE) {
  # extract the required height
  storm.data <- storm.obj$data
  id <- which(sapply(storm.data, function(x) x$height == height, 
    USE.NAMES=FALSE))

  if(length(id) == 0)
    return(NA)

  tmp.pts <- storm.data[[id]]$sp.pts
  tmp.grid.topo <- storm.data[[id]]$gridTopo
  tmp.mat <- bbox(tmp.pts)
  cells.dim <- round((tmp.mat[,2] - tmp.mat[,1] ) / 
    tmp.grid.topo@cellsize) + 10

  tmp.grid.topo <- GridTopology(tmp.mat[,1]-2*tmp.grid.topo@cellsize, 
    tmp.grid.topo@cellsize, cells.dim)

  sp.grid <- SpatialGrid(tmp.grid.topo, CRS(proj4string(tmp.pts)))
  id <- over(as(tmp.pts, "SpatialPoints"), sp.grid)
  storm.identifier <- rep(0, prod(tmp.grid.topo@cells.dim))
  storm.identifier[id] <- 1
  sp.grid <- SpatialGridDataFrame(sp.grid, data.frame(storm.identifier))
  sp.poly <- Grid2Polygons(sp.grid, at=c(-0.5, 0.5, 1.5))

  if(length(sp.poly) > 1) {
    id <- which(sp.poly$z == 1)
    sp.poly <- sp.poly[id,]
  }

  if(convex.hull)
    sp.poly <- gConvexHull(sp.poly)

  as(sp.poly, "SpatialPolygons")
}

#####################
# For matching storms
#####################
distStormListStormList <- function(stormList.1, stormList.2) {
  # to compute the distance between two stormLists
  # Each storm list should contain storms at one time scan

  x <- ldply(stormList.1, function(x) x$stats[,c("Centroid.x", "Centroid.y")])
  x$'.id' <- "storm.1"
  y <- ldply(stormList.2, function(x) x$stats[,c("Centroid.x", "Centroid.y")])
  y$'.id' <- "storm.2"
  
  out <- rbind(x,y)
  num.storm.1 <- length(stormList.1)
  num.storm.2 <- length(stormList.2)
  out <- as.matrix(dist(out[,-1]))/1000

  out[ (num.storm.1+1):(num.storm.1+num.storm.2), 1:num.storm.1]
}

matchStormListsDistance <- function(stormList.1, stormList.2, dist.crit=10) {
  # distance criteria is in km travelled per 5 min interval
  # to compute the distance between two stormLists
  # Each storm list should contain storms at one time scan
  
  num.storm.1 <- length(stormList.1)
  num.storm.2 <- length(stormList.2)
  dist.mat <- distStormListStormList(stormList.1, stormList.2)
  if(class(dist.mat) == "numeric")
    dist.mat <- matrix(dist.mat, nrow=num.storm.2, ncol=num.storm.1)
  rownames(dist.mat) <- 1:num.storm.2
  colnames(dist.mat) <- 1:num.storm.1
  ifelse(dist.mat <= dist.crit, 1, 0)
}

matchStormListsArea <- function(stormList.1, stormList.2, overlap.crit=75) {
  # overlap is in terms of area of overlap, and it takes the maximum overlap, 
  # i.e., change/min(area1, area2)
  num.storm.1 <- length(stormList.1)
  num.storm.2 <- length(stormList.2)
  stormList.1.polys <- llply(stormList.1, projectStorm)
  stormList.2.polys <- llply(stormList.2, projectStorm)
  
  id <- expand.grid(1:num.storm.2, 1:num.storm.1)

  out <- apply(id, 1, function(x) {area <-
    gIntersection(stormList.2.polys[[x[1]]],stormList.1.polys[[x[2]]]);
    if(class(area) == "SpatialPolygons")
      return(area@polygons[[1]]@area/1e+06) else
      return(0)})
  out <- matrix(out, nrow=num.storm.2, ncol=num.storm.1)

  stormList.1.area <- laply(stormList.1.polys, function(x)
    x@polygons[[1]]@area/1e+06)
  stormList.2.area <- laply(stormList.2.polys, function(x)
    x@polygons[[1]]@area/1e+06)

  out.array <- array(0, c(num.storm.2, num.storm.1,2))
  out.array[,,1] <- t(apply(out, 1, function(x) x/stormList.1.area))
  out.array[,,2] <- apply(out, 2, function(x) x/stormList.2.area)
  out <- apply(out.array, c(1,2), max)
  out <- ifelse(out*100 >= overlap.crit, 1, 0)
  rownames(out) <- 1:num.storm.2
  colnames(out) <- 1:num.storm.1
  out
}

matchStormListsSize <- function(stormList.1, stormList.2, change.crit=15) {
  # change is in terms of min percentage change
  # i.e., change/max(area1, area2)
  # this is not a good idea. Dropped.
  num.storm.1 <- length(stormList.1)
  num.storm.2 <- length(stormList.2)
  stormList.1.vol <- laply(stormList.1, function(x) x$stats$Pixel.Area)
  stormList.2.vol <- laply(stormList.2, function(x) x$stats$Pixel.Area)
  
  id <- expand.grid(1:num.storm.2, 1:num.storm.1)

  out <- apply(id, 1, function(x) {
    delta <- abs(stormList.2.vol[x[1]] - stormList.1.vol[x[2]])
    delta/max(stormList.2.vol[x[1]], stormList.1.vol[x[2]])})
  out <- matrix(out, nrow=num.storm.2, ncol=num.storm.1)

  ifelse(out*100 <= change.crit, 1, 0)
}

matchStormListsSize2 <- function(stormList.1, stormList.2, change.crit=15) {
  # change is in terms of min percentage change
  # i.e., change/max(area1, area2)
  # this is not a good idea. Dropped.
  num.storm.1 <- length(stormList.1)
  num.storm.2 <- length(stormList.2)
  stormList.1.vol <- laply(stormList.1, function(x) x$stats$Pixel.Area)
  stormList.2.vol <- laply(stormList.2, function(x) x$stats$Pixel.Area)
  
  tmp.mat <- matrix(0, nrow=num.storm.2, ncol=num.storm.2)
  id <- which(lower.tri(tmp.mat), arr.ind=TRUE)
  stormList.2a.vol <- apply(id, 1, function(x) stormList.2.vol[x[1]] +
    stormList.2.vol[x[2]])

  id <- sapply(stormList.1.vol, function(x) {
    delta <- abs(x - stormList.2a.vol)
    pct <- delta/pmax(x, stormList.2a.vol)
    which(pct*100 <= 15)
  })
  out.1 <- lapply(id, function(x){
    y <- rep(0, num.storm.1);
    if(length(x) > 0) {
      y[x] <- 1;
      return(y)
    } else {
      return(y)
    } })
  out <- matrix(out, nrow=num.storm.2, ncol=num.storm.1)

  ifelse(out*100 <= change.crit, 1, 0)
}

matchStormListsDistance2 <- function(stormList.1, stormList.2, dist.crit=8) {
  # checks which pair of storms are closely associated with an individual storm.
  num.storm.1 <- length(stormList.1)
  num.storm.2 <- length(stormList.2)
  stormList.1.vol <- laply(stormList.1, function(x) x$stats$Pixel.Area)
  stormList.2.vol <- laply(stormList.2, function(x) x$stats$Pixel.Area)
  stormList.1.centroids <- ldply(stormList.1, function(x) 
    x$stats[,c("Centroid.x", "Centroid.y")])
  stormList.2.centroids <- ldply(stormList.2, function(x) 
    x$stats[,c("Centroid.x", "Centroid.y")])
  
  if(num.storm.2 >= 2) {
    tmp.mat <- matrix(0, nrow=num.storm.2, ncol=num.storm.2)
    id <- which(lower.tri(tmp.mat), arr.ind=TRUE)
    stormList.2a.centroid <- apply(id, 1, function(x) 
      (stormList.2.vol[x[1]]*stormList.2.centroids[x[1],2:3] +
      stormList.2.vol[x[2]]*stormList.2.centroids[x[2],2:3])/
      (stormList.2.vol[x[1]] + stormList.2.vol[x[2]]))
    stormList.2a.centroid <- t(drop(simplify2array(stormList.2a.centroid)))

    out <- rbind(stormList.1.centroids[,-1],stormList.2a.centroid)
    out <- as.matrix(dist(out, diag=TRUE))/1000
    out <- out[(num.storm.1+1):(num.storm.1+nrow(id)) , 1:num.storm.1]
    if(class(out) == "numeric")
      out <- matrix(out, nrow=nrow(id), ncol=num.storm.1)
    
    out.1 <- apply(out, 2, function(x) {
      min.dist <- min(x);
      y <- rep(0, num.storm.2);
      if(min.dist > dist.crit)
	return(y) else
	{
	  y[id[which.min(x),]] <- 1;
	  return(y)
	}
    })
  } else {
    out.1 <- matrix(0, nrow=1, ncol=num.storm.1)
  }
  
  if(num.storm.1 >= 2) {
    tmp.mat <- matrix(0, nrow=num.storm.1, ncol=num.storm.1)
    id <- which(lower.tri(tmp.mat), arr.ind=TRUE)
    stormList.1a.centroid <- apply(id, 1, function(x) 
      (stormList.1.vol[x[1]]*stormList.1.centroids[x[1],2:3] +
      stormList.1.vol[x[2]]*stormList.1.centroids[x[2],2:3])/
      (stormList.1.vol[x[1]] + stormList.1.vol[x[2]]))
    stormList.1a.centroid <- t(drop(simplify2array(stormList.1a.centroid)))

    out <- rbind(stormList.2.centroids[,-1],stormList.1a.centroid)
    out <- as.matrix(dist(out, diag=TRUE))/1000
    out <- out[(num.storm.2+1):(num.storm.2+nrow(id)) , 1:num.storm.2]
    if(class(out) == "numeric")
      out <- matrix(out, nrow=nrow(id), ncol=num.storm.2)
    
    out.2 <- apply(out, 2, function(x) {
      min.dist <- min(x);
      y <- rep(0, num.storm.1);
      if(min.dist > dist.crit)
	return(y) else
	{
	  y[id[which.min(x),]] <- 1;
	  return(y)
	}
    })
    out.2 <- t(out.2)
  } else {
    out.2 <- matrix(0, nrow=num.storm.2, ncol=1)
  }

  out <- 0.5*(out.1+out.2)
  rownames(out) <- 1:num.storm.2
  colnames(out) <- 1:num.storm.1
  out
}

updateTrackInfo <- function(track.info=NULL, match.info) {
  # update track information with the output of the three matchXXXXX algorithms
  match.id <- ifelse(match.info >=1.5, 1, 0) # is 1.5 ideal?

  if(is.null(track.info)){
    births.id <- which(rowSums(match.id) == 0)
    if(length(births.id) > 0) {
      track.info <- c(track.info, paste("*-",
        rownames(match.info)[births.id],sep=""))
    }
    deaths.id <- which(colSums(match.id) == 0)
    if(length(deaths.id) > 0) {
      track.info <- c(track.info, 
        paste(colnames(match.info)[deaths.id], "-*", sep=""))
    }

    edge.id <- which(match.id == 1, arr.ind=TRUE)
    edge.info <- apply(edge.id, 1, function(x) 
      paste(colnames(match.info)[x[2]], 
      rownames(match.info)[x[1]], sep="-"))
    names(edge.info) <- NULL
    track.info <- c(track.info, edge.info)
  } else {
    births.id <- which(rowSums(match.id) == 0)
    if(length(births.id) > 0) {
      track.info <- c(track.info, paste("*-",
        rownames(match.info)[births.id],sep=""))
    }
    deaths.id <- which(colSums(match.id) == 0)
    if(length(deaths.id) > 0) {
      kill.storm.num <- colnames(match.info)[deaths.id]
      kill.id <- sapply(paste("-", kill.storm.num, sep=""), grep, track.info)
      kill.id <- unique(unlist(kill.id))
      track.info[kill.id] <- paste(track.info[kill.id], "-*", sep="")
    }

    edge.id <- which(match.id == 1, arr.ind=TRUE)
    for(i in 1:ncol(match.id)){
      col.values <- match.id[,i]
      if(sum(col.values)==0)
        next else if(sum(col.values)==1) {
	extend.storm.num <- colnames(match.info)[i]
	extend.id <- grep(paste("-",extend.storm.num,sep=""), track.info)
	extend.by.storm.num <- rownames(match.info)[which(col.values==1)]
	track.info[extend.id] <- paste(track.info[extend.id], "-",
	  extend.by.storm.num, sep="")
      } else {
	extend.storm.num <- colnames(match.info)[i]
	extend.id <- grep(paste("-",extend.storm.num,sep=""), track.info)
	extend.by.storm.num <- rownames(match.info)[which(col.values==1)]
	extend.grid <- expand.grid(track.info[extend.id], extend.by.storm.num,
	  stringsAsFactors=FALSE)
	add.these <- apply(extend.grid, 1, paste, collapse="-")
	track.info <- c(track.info, add.these)
	track.info <- track.info[-extend.id]
      }
    }
  }
  track.info
}

processTrackInfo <- function(track.info) {
  # process the output of the updateTrackInfo object to reduce
  # duplication/overlap in tracks.
  prelim.list <- vector(mode="list", length=length(track.info))
  for(i in 1:length(prelim.list))
    prelim.list[[i]] <- track.info[i]

  hit <- TRUE

  while(hit) {
    hit <- FALSE
    for(i in 1:(length(prelim.list)-1)) {
      for(j in (i+1):length(prelim.list)) {
	split.strings.i <- unique(unlist(strsplit(prelim.list[[i]], "-")))
	split.strings.i <- split.strings.i[split.strings.i!="*"]

	split.strings.j <- unique(unlist(strsplit(prelim.list[[j]], "-")))
	split.strings.j <- split.strings.j[split.strings.j!="*"]

	if(length(intersect(split.strings.i, split.strings.j) > 0)) {
	  hit <- TRUE
	  prelim.list[[i]] <- c(prelim.list[[i]], prelim.list[[j]])
	  prelim.list <- prelim.list[-j]
          break
	}
      }
      if(hit & length(prelim.list)>1) {
        break 
      } else if(hit & length(prelim.list)==1) {
        hit <- FALSE
      }
    }
  }

  prelim.list
}

##############################################
# to convert a track to a SpatialLines object.
##############################################
trackToLines <- function(track, storm.list, ID='X') {
  # A track would look something like "1-4-6-*"
  ids <- unique(strsplit(track, "-")[[1]])
  ids <- as.numeric(ids[ids != '*'])

  start.to.end <- ldply(storm.list[ids], function(x) 
    x$stats[ ,c("Centroid.x", "Centroid.y")])

  l1 <- Lines(list(Line(start.to.end[,-1])), ID=ID)
  l1 <- SpatialLines(list(l1), proj4string =
   CRS(proj4string(storm.list[[ids[1]]]$data[[1]]$sp.pts)))
  
  l1
}

convertEllipseRep <- function(major.length, minor.length, angle) {
 
  major.axis <- c(major.length, 0)
  minor.axis <- c(0, minor.length)
    
  rot.matrix <- matrix(c(cos(angle), sin(angle), -sin(angle),
    cos(angle)), nrow=2, ncol=2)

  out <- rot.matrix %*% cbind(major.axis, minor.axis)
  out

}

processCoords <- function(x) {
  y <- strsplit(x, ",")[[1]]

  if(length(y) == 2)
    return(rep(NA, 3))

  out <- as.numeric(y)
  out[1:2] <- out[1:2] + 1
  out
}

processLine <- function(line1) {
  end.pts <- strsplit(line1, "\\),\\(")[[1]]

  end.pts <- ifelse(substring(end.pts, 1, 1) == "(", 
    substring(end.pts, first=2), end.pts)
  end.pts <- ifelse(substring(end.pts, first=nchar(end.pts)-1) == "),", 
    substring(end.pts, first=1, last=nchar(end.pts)-2), end.pts)

  out <- t(sapply(end.pts, processCoords, USE.NAMES=FALSE))
  out <- as.data.frame(out)
  names(out) <- c("row", "col", "correlation")
  out
}

### R code from vignette source 'selextR.Rnw'

###################################################
### code chunk number 1: load_library
###################################################
library(selextR)
#path.to.rbclient <- "/nfs/home/viknes/NEA/STAT++/cdom/radar"
#java <- "java"
start.time <- "2011-05-20 06:04:00"
end.time <- "2011-05-20 07:55:00"
#rbclientR(start.time, end.time, "10.0.0.8", 9999, path.to.rbclient, 
#out.file='demo.json')
rbclientR(start.time, end.time, out.file='demo.json')


###################################################
### code chunk number 2: summarise_SelexScanList
###################################################
demo.out <- createSelexScanList('demo.json')
head( summary(demo.out), n=6)


###################################################
### code chunk number 3: structure_SelexScanList
###################################################
str(demo.out[[1]], max=2)


###################################################
### code chunk number 4: plot_SelexScan
###################################################
plot(demo.out[[1]], boundaries=TRUE)


###################################################
### code chunk number 5: plot_SelexScan_zoom
###################################################
plot(demo.out[[1]], boundaries=TRUE, xlim=c(0, 60000), ylim=c(0, 55000))


###################################################
### code chunk number 6: plot_SelexScan_agg_zoom
###################################################
plot(spatAgg(demo.out[[1]], c(5,5)), boundaries=TRUE, xlim=c(0, 60000), 
ylim=c(0, 55000))


###################################################
### code chunk number 7: storm_detection
###################################################
stormDetectionR(java, json.file='demo.json', out.file='demo.csv', size.thresh=1000,
ref.thresh=35, algorithm='titan')
storm.stats <- readStormStats('demo.csv.stats')
storm.obj.raw <- readStormObjects('demo.csv')
storm.list <- createStormList(storm.obj.raw, demo.out, storm.stats)
head(summary(storm.list, verbosity=2), n=7)


###################################################
### code chunk number 8: storm_object_structure
###################################################
str(storm.list[[1]], max=2)


###################################################
### code chunk number 9: plot_storm_objects_1
###################################################
plot(storm.list[1:4], boundaries=TRUE)


###################################################
### code chunk number 10: plot_storm_objects_2
###################################################
plot(storm.list[13:15], boundaries=TRUE, label=TRUE)


###################################################
### code chunk number 11: plot_storm_objects_3
###################################################
plot(storm.list[13:15], boundaries=TRUE, convex.hull=TRUE)


###################################################
### code chunk number 12: plot_storm_objects_scan_1
###################################################
plot(demo.out[[1]], storm.list, boundaries=TRUE, convex.hull=TRUE)


###################################################
### code chunk number 13: plot_storm_objects_scan_2
###################################################
plot(demo.out[[5]], storm.list, boundaries=TRUE, convex.hull=TRUE)


###################################################
### code chunk number 14: match_storms_1
###################################################
track.info <- matchStorms(storm.list)
length(track.info)
track.info[[2]]
ids <- unique(strsplit(track.info[[2]], "-")[[1]])
ids <- as.numeric(ids[ids != '*'])
storm.track <- createStormTrack(storm.list[ids])


###################################################
### code chunk number 15: plot_match_storms_1
###################################################
plot(storm.list[2], convex.hull=TRUE, height=1)


###################################################
### code chunk number 16: plot_match_storms_2
###################################################
plot(storm.list[59], convex.hull=TRUE, height=1)


###################################################
### code chunk number 17: plot_match_storms_3
###################################################
plot(storm.track, boundaries=TRUE, zoom=2, lwd=2)


###################################################
### code chunk number 18: match_storms_2
###################################################
track.info[[14]]
branch.1 <- createStormTrack(storm.list[c(62,66,70,74,78,83)])
branch.2 <- createStormTrack(storm.list[c(62,66,70,75,80,85)])


###################################################
### code chunk number 19: plot_match_storms_4
###################################################
plot(storm.list[62], convex.hull=TRUE, height=1)


###################################################
### code chunk number 20: plot_match_storms_5
###################################################
plot(storm.list[c(83,85)], convex.hull=TRUE, height=1)


###################################################
### code chunk number 21: plot_match_storms_6
###################################################
plot(branch.1, boundaries=TRUE, zoom=2, lwd=2)


###################################################
### code chunk number 22: plot_match_storms_7
###################################################
plot(branch.2, boundaries=TRUE, zoom=2, lwd=2)


###################################################
### code chunk number 23: list_features
###################################################
getFeatures("list")


###################################################
### code chunk number 24: extract_features
###################################################
extract.features <- getFeatures(storm.track, c("MaxRef", "Volume", "PlanarArea", 
  "RefQtles"), height=1, qtles=c(10, 90))


###################################################
### code chunk number 25: plot_features
###################################################
max.ref <- apply(extract.features[,3:7], 1, max)
plot(x=extract.features$timestamp, y=max.ref, type='o', ylim=c(45, 75),
main="Maximum reflectivity", xlab="Time", ylab="dBZ", col="red", 
xlim=range(summary(storm.list)$timestamp))
extract.features <- getFeatures(branch.1, c("MaxRef", "Volume", "PlanarArea", 
  "RefQtles"), height=1, qtles=c(10, 90))
max.ref <- apply(extract.features[,3:7], 1, max)
lines(x=extract.features$timestamp, y=max.ref, type='o', col='blue')
legend("topright", legend=c("storm.track", "branch.1"), col=c('red', 'blue'),
  lwd=1)


###################################################
### code chunk number 26: cdom
###################################################
(rain.data <- getFeatures(storm.track, "Rainfall"))
colSums(rain.data[ , -(1:2)])


###################################################
### code chunk number 27: plot_rain_1
###################################################
plot(rain.data[,1], rain.data[, "S.66"], col=1, type='o', main='Storm rainfall',
xlab='Time', ylab='Rainfall (mm)', ylim=c(0,12))
lines(rain.data[,1], rain.data[, "S.104"], col=2, type='o')
lines(rain.data[,1], rain.data[, "S.105"], col=3, type='o')
legend("topleft", col=1:3, lty=1, legend=c("S.66", "S.104", "S.105"))


###################################################
### code chunk number 28: plot_rain_2
###################################################
plot(sgBd, axes=TRUE)
grid()
title('Locations with highest rainfall')
plot(stns[stns$Stn %in% c(66,104,105),], pch=20, cex=2, add=TRUE, col='red')
text(coordinates(stns[stns$Stn == 66,]), "S.66", col='red', font=2, pos=3)
text(coordinates(stns[stns$Stn == 104,]), "S.104", col='red', font=2, pos=1)
text(coordinates(stns[stns$Stn == 105,]), "S.105", col='red', font=2, pos=3)


###################################################
### code chunk number 29: getting_help_1 (eval = FALSE)
###################################################
## ?rbclientR


###################################################
### code chunk number 30: getting_help_2 (eval = FALSE)
###################################################
## vignette('selextR')


###################################################
### code chunk number 31: getting_help_3 (eval = FALSE)
###################################################
## ## demo('selextR')



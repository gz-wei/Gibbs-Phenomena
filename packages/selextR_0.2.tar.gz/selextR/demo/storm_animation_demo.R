library(selextR)
library(animation)

start.time <- "2011-05-20 06:04:00"
end.time <- "2011-05-20 07:55:00"
rbclientR(start.time, end.time, out.file='demo.json')

scan.list <- createSelexScanList('demo.json')
stormDetectionR(json.file='demo.json', out.file='demo.csv', ref.thresh=30, 
  size.thresh=500)
storm.info <- readStormObjects('demo.csv')
storm.stats <- readStormStats('demo.csv.stats')
storm.list <- createStormList(storm.info, scan.list, storm.stats)

track.info <- matchStorms(storm.list)

storm.group <- track.info[[46]]
all.ids <- unlist(strsplit(storm.group,"-"))
remove.these <- which(all.ids == "*")
if(length(remove.these) > 0)
  all.ids <- all.ids[-remove.these]

all.ids <- as.integer(all.ids)
all.ids <- sort(unique(all.ids))

sub.storm.list <- storm.list[all.ids]
sub.storm.list.df <- summary(sub.storm.list)
vars <- as.data.frame(sub.storm.list.df[,"timestamp"])
plot.ids <- id(vars)

nmax.1 <- length(plot.ids)
oopt = ani.options(interval = 0.3, nmax = nmax.1)
for(i in 1:nmax.1) {
  plot.these <- which(plot.ids == i)
  if(length(plot.these) > 0) {
    plot(sub.storm.list[plot.these], conve=TRUE)
  } 
  ani.pause()
}
ani.options(oopt)

#oopt <- ani.options(outdir="C:\\Documents and Settings\\Administrator\\My Documents\\NEA\\heavyRainGust\\Rpkg\\stormSummary")
#saveLatex({
#  for(i in 1:length(plot.ids)) {
#  plot.these <- which(plot.ids == i)
#  if(length(plot.these) > 0) {
#    plot(sub.storm.list[plot.these], conve=TRUE)
#    # plot(sub.storm.list[plot.these], conve=TRUE, xlim=c(25000,150000),
#    #  ylim=c(25000,150000))
#  } 
#  ani.pause()
#  }}, 
#img.name="test_1", ani.dev="pdf", ani.type="pdf", interval=0.2, nmax=nmax.1, 
#ani.width=5, ani.height=5)
#ani.options(oopt)
